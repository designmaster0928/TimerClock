/*
 * TempProbe.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_TEMPPROBE_H_
#define SRC_TEMPPROBE_H_

//TempProbe specific Infos

#define DS18B20_FAMILY_CODE				0x28
#define DS18B20_CMD_ALARMSEARCH			0xEC

/* DS18B20 read temperature command */
#define DS18B20_CMD_CONVERTTEMP			0x44 	/* Convert temperature */
#define DS18B20_DECIMAL_STEPS_12BIT		0.0625
#define DS18B20_DECIMAL_STEPS_11BIT		0.125
#define DS18B20_DECIMAL_STEPS_10BIT		0.25
#define DS18B20_DECIMAL_STEPS_9BIT		0.5

/* Bits locations for resolution */
#define DS18B20_RESOLUTION_R1			6
#define DS18B20_RESOLUTION_R0			5

/* CRC enabled */
#ifdef DS18B20_USE_CRC
#define DS18B20_DATA_LEN				9
#else
#define DS18B20_DATA_LEN				2
#endif

void TempProbe_Handle(void);
void ChipProbe_Handle(void);

#endif /* SRC_TEMPPROBE_H_ */
