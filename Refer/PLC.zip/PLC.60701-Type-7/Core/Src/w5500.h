#ifndef	_W5500_H_
#define	_W5500_H_

/***************** Common Register *****************/
#define MR		0x0000
	#define RST		0x80
	#define WOL		0x20
	#define PB		0x10
	#define PPP		0x08
	#define FARP	0x02

#define GAR		0x0001
#define SUBR	0x0005
#define SHAR	0x0009
#define SIPR	0x000f

#define INTLEVEL	0x0013
#define IR		0x0015
	#define CONFLICT	0x80
	#define UNREACH		0x40
	#define PPPOE		0x20
	#define MP			0x10

#define IMR		0x0016
	#define IM_IR7		0x80
	#define IM_IR6		0x40
	#define IM_IR5		0x20
	#define IM_IR4		0x10

#define SIR		0x0017
	#define S7_INT		0x80
	#define S6_INT		0x40
	#define S5_INT		0x20
	#define S4_INT		0x10
	#define S3_INT		0x08
	#define S2_INT		0x04
	#define S1_INT		0x02
	#define S0_INT		0x01

#define SIMR	0x0018
	#define S7_IMR		0x80
	#define S6_IMR		0x40
	#define S5_IMR		0x20
	#define S4_IMR		0x10
	#define S3_IMR		0x08
	#define S2_IMR		0x04
	#define S1_IMR		0x02
	#define S0_IMR		0x01

#define RTR		0x0019
#define RCR		0x001b

#define PTIMER	0x001c
#define PMAGIC	0x001d
#define PHA		0x001e
#define PSID	0x0024
#define PMRU	0x0026

#define UIPR	0x0028
#define UPORT	0x002c

#define PHYCFGR	0x002e
	#define RST_PHY		0x80
	#define OPMODE		0x40
	#define DPX			0x04
	#define SPD			0x02
	#define LINK		0x01

#define VERR	0x0039

/********************* Socket Register *******************/
#define Sn_MR		0x0000
	#define MULTI_MFEN		0x80
	#define BCASTB			0x40
	#define	ND_MC_MMB		0x20
	#define UCASTB_MIP6B	0x10
	#define MR_CLOSE		0x00
	#define MR_TCP		0x01
	#define MR_UDP		0x02
	#define MR_MACRAW		0x04

#define Sn_CR		0x0001
	#define OPEN		0x01
	#define LISTEN		0x02
	#define CONNECT		0x04
	#define DISCON		0x08
	#define CLOSE		0x10
	#define SEND		0x20
	#define SEND_MAC	0x21
	#define SEND_KEEP	0x22
	#define RECV		0x40

#define Sn_IR		0x0002
	#define IR_SEND_OK		0x10
	#define IR_TIMEOUT		0x08
	#define IR_RECV			0x04
	#define IR_DISCON		0x02
	#define IR_CON			0x01

#define Sn_SR		0x0003
	#define SOCK_CLOSED		0x00
	#define SOCK_INIT		0x13
	#define SOCK_LISTEN		0x14
	#define SOCK_ESTABLISHED	0x17
	#define SOCK_CLOSE_WAIT		0x1c
	#define SOCK_UDP		0x22
	#define SOCK_MACRAW		0x02

	#define SOCK_SYNSEND	0x15
	#define SOCK_SYNRECV	0x16
	#define SOCK_FIN_WAI	0x18
	#define SOCK_CLOSING	0x1a
	#define SOCK_TIME_WAIT	0x1b
	#define SOCK_LAST_ACK	0x1d

#define Sn_PORT		0x0004
#define Sn_DHAR	   	0x0006
#define Sn_DIPR		0x000c
#define Sn_DPORTR	0x0010

#define Sn_MSSR		0x0012
#define Sn_TOS		0x0015
#define Sn_TTL		0x0016

#define Sn_RXBUF_SIZE	0x001e
#define Sn_TXBUF_SIZE	0x001f
#define Sn_TX_FSR	0x0020
#define Sn_TX_RD	0x0022
#define Sn_TX_WR	0x0024
#define Sn_RX_RSR	0x0026
#define Sn_RX_RD	0x0028
#define Sn_RX_WR	0x002a

#define Sn_IMR		0x002c
	#define IMR_SENDOK	0x10
	#define IMR_TIMEOUT	0x08
	#define IMR_RECV	0x04
	#define IMR_DISCON	0x02
	#define IMR_CON		0x01

#define Sn_FRAG		0x002d
#define Sn_KPALVTR	0x002f

/*******************************************************************/
/************************ SPI Control Byte *************************/
/*******************************************************************/
/* Operation mode bits */
#define VDM		0x00
#define FDM1	0x01
#define	FDM2	0x02
#define FDM4	0x03

/* Read_Write control bit */
#define RWB_READ	0x00
#define RWB_WRITE	0x04

/* Block select bits */
#define COMMON_R	0x00

/* Socket 0 */
#define S0_REG		0x08
#define S0_TX_BUF	0x10
#define S0_RX_BUF	0x18

/* Socket 1 */
#define S1_REG		0x28
#define S1_TX_BUF	0x30
#define S1_RX_BUF	0x38

/* Socket 2 */
#define S2_REG		0x48
#define S2_TX_BUF	0x50
#define S2_RX_BUF	0x58

/* Socket 3 */
#define S3_REG		0x68
#define S3_TX_BUF	0x70
#define S3_RX_BUF	0x78

/* Socket 4 */
#define S4_REG		0x88
#define S4_TX_BUF	0x90
#define S4_RX_BUF	0x98

/* Socket 5 */
#define S5_REG		0xa8
#define S5_TX_BUF	0xb0
#define S5_RX_BUF	0xb8

/* Socket 6 */
#define S6_REG		0xc8
#define S6_TX_BUF	0xd0
#define S6_RX_BUF	0xd8

/* Socket 7 */
#define S7_REG		0xe8
#define S7_TX_BUF	0xf0
#define S7_RX_BUF	0xf8

#define TRUE	0xff
#define FALSE	0x00

#define S_RX_SIZE	2048	/*¶¨ÒåSocket½ÓÊÕ»º³åÇøµÄ´óÐ¡£¬¿ÉÒÔ¸ù¾ÝW5500_RMSRµÄÉèÖÃÐÞ¸Ä */
#define S_TX_SIZE	2048  	/*¶¨ÒåSocket·¢ËÍ»º³åÇøµÄ´óÐ¡£¬¿ÉÒÔ¸ù¾ÝW5500_TMSRµÄÉèÖÃÐÞ¸Ä */

/***************----- W5500 GPIO¶¨Òå -----***************/
//#define W5500_SCS		GPIO_PIN_4	//¶¨ÒåW5500µÄCSÒý½Å
//#define W5500_SCS_PORT	GPIOC

//#define W5500_RST		GPIO_PIN_10	//¶¨ÒåW5500µÄRSTÒý½Å
//#define W5500_RST_PORT	GPIOC

//#define W5500_INT		GPIO_PIN_1	//¶¨ÒåW5500µÄINTÒý½Å
//#define W5500_INT_PORT	GPIOA

/***************----- ÍøÂç²ÎÊý±äÁ¿¶¨Òå -----***************/
extern unsigned char Gateway_IP[4];	//Íø¹ØIPµØÖ·
extern unsigned char Sub_Mask[4];	//×ÓÍøÑÚÂë
extern unsigned char Phy_Addr[6];	//ÎïÀíµØÖ·(MAC)
extern unsigned char IP_Addr[4];	//±¾»úIPµØÖ·

extern unsigned char S0_Port[2];	//Port number of port 0 (502)
extern unsigned char S1_Port[2];	//Port number of port 1 (512)
extern unsigned char S2_Port[2];	//Port number of port 2 (522)
extern unsigned char S3_Port[2];	//Port number of port 3 (532)
extern unsigned char S4_Port[2];	//Port number of port 4 (542)
extern unsigned char S5_Port[2];	//Port number of port 5 (552)
extern unsigned char S6_Port[2];	//Port number of port 6 (562)
extern unsigned char S7_Port[2];	//Port number of port 7 (572)

extern unsigned char S0_DIP[4];		//port 0 destination IP address
extern unsigned char S1_DIP[4];		//port 1 destination IP address
extern unsigned char S2_DIP[4];		//port 2 destination IP address
extern unsigned char S3_DIP[4];		//port 3 destination IP address
extern unsigned char S4_DIP[4];		//port 4 destination IP address
extern unsigned char S5_DIP[4];		//port 5 destination IP address
extern unsigned char S6_DIP[4];		//port 6 destination IP address
extern unsigned char S7_DIP[4];		//port 7 destination IP address

extern unsigned char S0_DPort[2];	//Port 0 destination port number (6000)
extern unsigned char S1_DPort[2];	//Port 1 destination port number (6000)
extern unsigned char S2_DPort[2];	//Port 2 destination port number (6000)
extern unsigned char S3_DPort[2];	//Port 3 destination port number (6000)
extern unsigned char S4_DPort[2];	//Port 4 destination port number (6000)
extern unsigned char S5_DPort[2];	//Port 5 destination port number (6000)
extern unsigned char S6_DPort[2];	//Port 6 destination port number (6000)
extern unsigned char S7_DPort[2];	//Port 7 destination port number (6000)

extern unsigned char UDP_DIPR[4];	//UDP(¹ã²¥)Ä£Ê½,Ä¿µÄÖ÷»úIPµØÖ·
extern unsigned char UDP_DPORT[2];	//UDP(¹ã²¥)Ä£Ê½,Ä¿µÄÖ÷»ú¶Ë¿ÚºÅ

/***************----- ¶Ë¿ÚµÄÔËÐÐÄ£Ê½ -----***************/
extern unsigned char S0_Mode;	////Operation mode of port 0, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S1_Mode;	////Operation mode of port 1, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S2_Mode;	////Operation mode of port 2, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S3_Mode;	////Operation mode of port 3, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S4_Mode;	////Operation mode of port 4, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S5_Mode;	////Operation mode of port 5, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S6_Mode;	////Operation mode of port 6, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
extern unsigned char S7_Mode;	////Operation mode of port 7, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
#define TCP_SERVER		0x00	//TCP·þÎñÆ÷Ä£Ê½
#define TCP_CLIENT		0x01	//TCP¿Í»§¶ËÄ£Ê½
#define UDP_MODE		0x02	//UDP(¹ã²¥)Ä£Ê½

/***************----- ¶Ë¿ÚµÄÔËÐÐ×´Ì¬ -----***************/
extern unsigned char S0_State;	//Port 0 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S1_State;	//Port 1 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S2_State;	//Port 2 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S3_State;	//Port 3 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S4_State;	//Port 4 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S5_State;	//Port 5 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S6_State;	//Port 6 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
extern unsigned char S7_State;	//Port 7 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)

//Port 0 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
#define S_INIT		0x01	//The port is initialized
#define S_CONN		0x02	//The port is connected and data can be transmitted normally

/***************----- ¶Ë¿ÚÊÕ·¢Êý¾ÝµÄ×´Ì¬ -----***************/
extern unsigned char S0_Data;		//Status of port 0 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S1_Data;		//Status of port 1 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S2_Data;		//Status of port 2 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S3_Data;		//Status of port 3 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S4_Data;		//Status of port 4 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S5_Data;		//Status of port 5 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S6_Data;		//Status of port 6 receiving and sending data, 1: port receiving data, 2: port sending data completed
extern unsigned char S7_Data;		//Status of port 7 receiving and sending data, 1: port receiving data, 2: port sending data completed
#define S_RECEIVE		0x01		//¶Ë¿Ú½ÓÊÕµ½Ò»¸öÊý¾Ý°ü
#define S_TRANSMITOK	0x02		//¶Ë¿Ú·¢ËÍÒ»¸öÊý¾Ý°üÍê³É

/***************----- ¶Ë¿ÚÊý¾Ý»º³åÇø -----***************/
extern unsigned char Rx_Buffer[2048];	//¶Ë¿Ú½ÓÊÕÊý¾Ý»º³åÇø
extern unsigned char Tx_Buffer[2048];	//¶Ë¿Ú·¢ËÍÊý¾Ý»º³åÇø

extern unsigned char W5500_Interrupt;	//W5500ÖÐ¶Ï±êÖ¾(0:ÎÞÖÐ¶Ï,1:ÓÐÖÐ¶Ï)
typedef unsigned char SOCKET;			//×Ô¶¨Òå¶Ë¿ÚºÅÊý¾ÝÀàÐÍ

//extern void Delay(unsigned int d);//ÑÓÊ±º¯Êý(ms)
extern void W5500_GPIO_Configuration(void);//W5500 GPIO³õÊ¼»¯ÅäÖÃ
extern void W5500_NVIC_Configuration(void);//W5500 ½ÓÊÕÒý½ÅÖÐ¶ÏÓÅÏÈ¼¶ÉèÖÃ
extern void SPI_Configuration(void);//W5500 SPI³õÊ¼»¯ÅäÖÃ(STM32 SPI1)
extern void W5500_Hardware_Reset(void);//Ó²¼þ¸´Î»W5500
extern void W5500_Init(void);//³õÊ¼»¯W5500¼Ä´æÆ÷º¯Êý
extern unsigned char Detect_Gateway(void);//¼ì²éÍø¹Ø·þÎñÆ÷
extern void Socket_Init(SOCKET s);//Ö¸¶¨Socket(0~7)³õÊ¼»¯
extern unsigned char Socket_Connect(SOCKET s);//ÉèÖÃÖ¸¶¨Socket(0~7)Îª¿Í»§¶ËÓëÔ¶³Ì·þÎñÆ÷Á¬½Ó
extern unsigned char Socket_Listen(SOCKET s);//ÉèÖÃÖ¸¶¨Socket(0~7)×÷Îª·þÎñÆ÷µÈ´ýÔ¶³ÌÖ÷»úµÄÁ¬½Ó
extern unsigned char Socket_UDP(SOCKET s);//ÉèÖÃÖ¸¶¨Socket(0~7)ÎªUDPÄ£Ê½
extern unsigned short Read_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr);//Ö¸¶¨Socket(0~7)½ÓÊÕÊý¾Ý´¦Àí
extern void Write_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr, unsigned short size); //Ö¸¶¨Socket(0~7)·¢ËÍÊý¾Ý´¦Àí
extern void W5500_Interrupt_Process(void);//W5500ÖÐ¶Ï´¦Àí³ÌÐò¿ò¼Ü

extern unsigned char Read_W5500_1Byte(unsigned short reg);

#endif

