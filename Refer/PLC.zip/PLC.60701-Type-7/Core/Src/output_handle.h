/*
 * output_handle.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_OUTPUT_H_
#define SRC_OUTPUT_H_


void SPI2_Send_Byte(unsigned char dat);
void RelayOutput_Control(unsigned short dat);
void Outputs_Handle(void);

#endif /* SRC_OUTPUT_H_ */
