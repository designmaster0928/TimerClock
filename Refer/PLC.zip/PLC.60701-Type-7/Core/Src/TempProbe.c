/*
 * boardtests.c
 *
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 *
 *      Configure the Boards Parameter in the boardtest.h file
 */

#include "usart.h"
#include "DWT_Delay.h"
#include "Timer_Delay.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gpio.h"


GPIO_InitTypeDef GPIO_InitStruct;

void gpio_set_input (void)
{
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void gpio_set_output (void)
{
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

uint8_t ds18b20_init (void)
{
	gpio_set_output ();   // set the pin as output
	HAL_GPIO_WritePin (GPIOB, GPIO_PIN_5, RESET);  // pull the pin low

	delay_us(480);   // delay according to datasheet

	gpio_set_input ();    // set the pin as input
	delay_us(80);    // delay according to datasheet

	if (!(HAL_GPIO_ReadPin (GPIOB, GPIO_PIN_5)))    // if the pin is low i.e the presence pulse is there
	{
		delay_us(400);  // wait for 400 us
		return 0;
	}

	else
	{
		delay_us(400);
		return 1;
	}
}

void write (uint8_t data)
{
	gpio_set_output ();   // set as output

	for (int i=0; i<8; i++)
	{

		if ((data & (1<<i))!=0)  // if the bit is high
		{
			// write 1

			gpio_set_output ();  // set as output
			HAL_GPIO_WritePin (GPIOB, GPIO_PIN_5, RESET);  // pull the pin LOW
			delay_us(1);  // wait for  us

			gpio_set_input ();  // set as input
			delay_us(60);  // wait for 60 us
		}

		else  // if the bit is low
		{
			// write 0

			gpio_set_output ();
			HAL_GPIO_WritePin (GPIOB, GPIO_PIN_5, RESET);  // pull the pin LOW
			delay_us(60);  // wait for 60 us

			gpio_set_input ();
		}
	}
}


uint8_t read (void)
{
	uint8_t value=0;
	gpio_set_input ();

	for (int i=0;i<8;i++)
	{
		gpio_set_output ();   // set as output

		HAL_GPIO_WritePin (GPIOB, GPIO_PIN_5, RESET);  // pull the data pin LOW
		delay_us(2);  // wait for 2 us

		gpio_set_input ();  // set as input
		if (HAL_GPIO_ReadPin (GPIOB, GPIO_PIN_5))  // if the pin is HIGH
		{
			value |= 1<<i;  // read = 1
		}
		delay_us(60);  // wait for 60 us
	}
	return value;
}

void TempProbe_Handle(void)
{
	uint8_t check = 2, temp_l, temp_h;
	uint16_t temp;
	//float temperature;

	check = ds18b20_init ();

	write (0xCC);  // skip ROM
	write (0x44);  // convert t

	delay_ms(10);  // wait for 800 ms

	ds18b20_init ();
	write (0xCC);  // skip ROM
	write (0xBE);  // Read Scratchpad

	temp_l = read();
	temp_h = read();
	temp = (temp_h<<8)|temp_l;
	//temperature = (float)temp/16;

	holding_register_value[TemperatureProbe1_addr]=temp/1.6 - holding_register_value[TemperatureProbe1_Offset_addr];


	holding_register_value[CabinetTemperature_addr] = 	holding_register_value[TemperatureProbe1_addr];
	//return temperature;
}





//const float         AVG_SLOPE   = 4.3E-03;      // slope (gradient) of temperature line function  [V/°C]
//const float         V25         = 1.43;         // sensor's voltage at 25°C [V]
//const float         ADC_TO_VOLT = 3.3 / 4096;   // conversion coefficient of digital value to voltage [V]
//                                                // when using 3.3V ref. voltage at 12-bit resolution (2^12 = 4096)
//
//ADC_HandleTypeDef   hadc1;                      // ADC handle
//uint16_t            adcValue;                   // digital value of sensor
//float               vSense;                     // sensor's output voltage [V]
//float               temp;                       // sensor's temperature [°C]
//
//void ChipProbe_Handle(void)
//{
//	   HAL_ADC_Start(&hadc1);                                      // start analog to digital conversion
//	        while(HAL_ADC_PollForConversion(&hadc1, 1000000) != HAL_OK);// wait for completing the conversion
//	        adcValue = HAL_ADC_GetValue(&hadc1);                        // read sensor's digital value
//	        vSense = adcValue * ADC_TO_VOLT;                            // convert sensor's digital value to voltage [V]
//	        /*
//	         * STM32F103xx Reference Manual:
//	         * 11.10 Temperature sensor
//	         * Reading the temperature, Page 235
//	         * Temperature (in °C) = {(V25 - Vsense) / Avg_Slope} + 25
//	         */
//	        temp = (V25 - vSense) / AVG_SLOPE + 25.0f;                  // convert sensor's output voltage to temperature [°C]
//
//}
