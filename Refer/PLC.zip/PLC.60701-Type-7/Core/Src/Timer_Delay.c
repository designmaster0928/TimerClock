/*
 * Timer_Delay.c
 *
 *  Created on: Jun 22, 2020
 *      Author: Khaled Magdy
 */

#include "Timer_Delay.h"

#define TIMER  TIM4
volatile static TIM_HandleTypeDef HTIM4;
volatile static uint32_t gu32_ticks = 0;

void TimerDelay_Init(void)
{
	gu32_ticks = (HAL_RCC_GetHCLKFreq() / 1000000);
	HTIM4.Instance = TIMER;

    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};


    HTIM4.Init.Prescaler = gu32_ticks-1;
    HTIM4.Init.CounterMode = TIM_COUNTERMODE_UP;
    HTIM4.Init.Period = 65535;
    HTIM4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    HTIM4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    if (HAL_TIM_Base_Init(&HTIM4) != HAL_OK)
    {
      Error_Handler();
    }
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&HTIM4, &sClockSourceConfig) != HAL_OK)
    {
      Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&HTIM4, &sMasterConfig) != HAL_OK)
    {
      Error_Handler();
    }

    HAL_TIM_Base_Start(&HTIM4);

}

void delay_us(volatile uint16_t au16_us)
{
	HTIM4.Instance->CNT = 0;
	while (HTIM4.Instance->CNT < au16_us);
}

void delay_ms(volatile uint16_t au16_ms)
{
	while(au16_ms > 0)
	{
		HTIM4.Instance->CNT = 0;
		au16_ms--;
		while (HTIM4.Instance->CNT < 1000);
	}
}
