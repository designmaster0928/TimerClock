/*
 * EEPROM_Handle.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_EEPROM_H_
#define SRC_EEPROM_H_


#include "main.h"


uint32_t Flash_Write_Data (uint32_t StartPageAddress, uint32_t *Data, uint16_t numberofwords);

void Flash_Read_Data (uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords);

void Convert_To_Str (uint32_t *Data, char *Buf);

void Flash_Write_NUM (uint32_t StartSectorAddress, float Num);

float Flash_Read_NUM (uint32_t StartSectorAddress);

void Flash_update(void);

#endif /* SRC_EEPROM_H_ */
