/**********************************************************************************
 * File name: W5500.c
 * Description: W5500 driver function library
 * Library version: ST_v3.5
 * Found at  https://github.com/zthxxx/STM32-W5500_TCP_Client/blob/master/USER/W5500.c
 * Translated with Google Translate from Chinese to English / Andreas Kisch
 **********************************************************************************/

#include "stm32f1xx.h"
#include "stm32f1xx_hal_spi.h"

#include "W5500.h"	
#include "stdio.h"
#include "spi.h"

/****************----- Network parameter variable definition -----****************/
unsigned char Gateway_IP[4]; //Gateway IP address
unsigned char Sub_Mask[4];	///Subnet mask
unsigned char Phy_Addr[6];	//physical address (MAC)
unsigned char IP_Addr[4];	//Local IP address

unsigned char S0_Port[2];	//Port number of port 0 (502)
unsigned char S1_Port[2];	//Port number of port 1 (512)
unsigned char S2_Port[2];	//Port number of port 2 (522)
unsigned char S3_Port[2];	//Port number of port 3 (532)
unsigned char S4_Port[2];	//Port number of port 4 (542)
unsigned char S5_Port[2];	//Port number of port 5 (552)
unsigned char S6_Port[2];	//Port number of port 6 (562)
unsigned char S7_Port[2];	//Port number of port 7 (572)

unsigned char S0_DIP[4];	//port 0 destination IP address
unsigned char S1_DIP[4];	//port 1 destination IP address
unsigned char S2_DIP[4];	//port 2 destination IP address
unsigned char S3_DIP[4];	//port 3 destination IP address
unsigned char S4_DIP[4];	//port 4 destination IP address
unsigned char S5_DIP[4];	//port 5 destination IP address
unsigned char S6_DIP[4];	//port 6 destination IP address
unsigned char S7_DIP[4];	//port 7 destination IP address

unsigned char S0_DPort[2];	//Port 0 destination port number (6000)
unsigned char S1_DPort[2];	//Port 1 destination port number (6000)
unsigned char S2_DPort[2];	//Port 2 destination port number (6000)
unsigned char S3_DPort[2];	//Port 3 destination port number (6000)
unsigned char S4_DPort[2];	//Port 4 destination port number (6000)
unsigned char S5_DPort[2];	//Port 5 destination port number (6000)
unsigned char S6_DPort[2];	//Port 6 destination port number (6000)
unsigned char S7_DPort[2];	//Port 7 destination port number (6000)

unsigned char UDP_DIPR[4];	//UDP (broadcast) mode, destination host IP address
unsigned char UDP_DPORT[2];	//UDP (broadcast) mode, destination host port number

/***************----- ¶Ë¿ÚµÄÔËÐÐÄ£Ê½ -----***************/
unsigned char S0_Mode = 3;//Operation mode of port 0, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S1_Mode = 3;//Operation mode of port 1, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S2_Mode = 3;//Operation mode of port 2, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S3_Mode = 3;//Operation mode of port 3, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S4_Mode = 3;//Operation mode of port 4, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S5_Mode = 3;//Operation mode of port 5, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S6_Mode = 3;//Operation mode of port 6, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
unsigned char S7_Mode = 3;//Operation mode of port 7, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode

//The operation mode of port 0, 0: TCP server mode, 1: TCP client mode, 2: UDP (broadcast) mode
#define TCP_SERVER	0x00	//TCP server mode
#define TCP_CLIENT	0x01	//TCP client mode
#define UDP_MODE	0x02	//UDP (broadcast) mode

/****************----- Port running status -----****************/
unsigned char S0_State = 0;	//Port 0 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S1_State = 0;	//Port 1 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S2_State = 0;	//Port 2 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S3_State = 0;	//Port 3 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S4_State = 0;	//Port 4 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S5_State = 0;	//Port 5 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S6_State = 0;	//Port 6 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
unsigned char S7_State = 0;	//Port 7 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)

//Port 0 status record, 1: port completes initialization, 2 port completes connection (data can be transmitted normally)
#define S_INIT		0x01	//The port is initialized
#define S_CONN		0x02	//The port is connected and data can be transmitted normally

/***************----- ¶Ë¿ÚÊÕ·¢Êý¾ÝµÄ×´Ì¬ -----***************/
unsigned char S0_Data;//Status of port 0 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S1_Data;//Status of port 1 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S2_Data;//Status of port 2 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S3_Data;//Status of port 3 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S4_Data;//Status of port 4 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S5_Data;//Status of port 5 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S6_Data;//Status of port 6 receiving and sending data, 1: port receiving data, 2: port sending data completed
unsigned char S7_Data;//Status of port 7 receiving and sending data, 1: port receiving data, 2: port sending data completed
#define S_RECEIVE	 0x01	//The port received a packet
#define S_TRANSMITOK 0x02	//The port has completed sending a data packet

/***************----- ¶Ë¿ÚÊý¾Ý»º³åÇø -----***************/
unsigned char Rx_Buffer[2048];
unsigned char Tx_Buffer[2048];

unsigned char W5500_Interrupt;

/*******************************************************************************
 * Function name: SPI1_Send_Byte
 * Description: SPI sends 1 byte of data (8 bits)
 * Input: dat: 8-bit data to be sent
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void SPI1_Send_Byte(unsigned char dat) {
	HAL_SPI_Transmit(&hspi1, &dat, 1, HAL_MAX_DELAY);
}

/*******************************************************************************
 * Function name: W5500_SPI_Send_Short
 * Description: SPI sends 2 bytes of data (16 bits)
 * Input: dat: 16-bit data to be sent
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void SPI1_Send_Short(uint16_t dat) {
	SPI1_Send_Byte(dat / 256);	//Write data high
	SPI1_Send_Byte(dat);		//Write data low bit
}

/*******************************************************************************
 * Function name: Write_W5500_1Byte
 * Description: Write 1 byte of data to the specified address register via SPI
 * Input: reg: 16-bit register address, dat: data to be written
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_1Byte(unsigned short reg, unsigned char dat) {
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | COMMON_R);	//Write control byte through SPI, 1 byte data length, write data, select general register
	SPI1_Send_Byte(dat);					//Write 1 byte of data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Write_W5500_2Byte
 * Description: Write 2 bytes of data to the specified address register via SPI
 * Input: reg: 16-bit register address, dat: 16-bit data to be written (2 bytes)
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_2Byte(unsigned short reg, unsigned short dat) {
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | COMMON_R);	//Write control byte through SPI, 2 bytes data length, write data, select general register
	SPI1_Send_Short(dat);					//Write 16-bit data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Write_W5500_nByte
 * Description: Write n bytes of data to the specified address register through SPI
 * Input: reg: 16-bit register address, *dat_ptr: pointer of data buffer to be written, size: length of data to be written
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_nByte(unsigned short reg, unsigned char *dat_ptr,
		unsigned short size) {
	unsigned short i;

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | COMMON_R);	//Write control byte through SPI, N bytes data length, write data, select general register

	for (i = 0; i < size; i++)//Write the size bytes of data in the buffer to W5500 in a loop
			{
		SPI1_Send_Byte(*dat_ptr++);			//Write a byte of data
	}

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Write_W5500_SOCK_1Byte
 * Description: Write 1 byte of data to the specified port register via SPI
 * Input: s: port number, reg: 16-bit register address, dat: data to be written
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_SOCK_1Byte(SOCKET s, unsigned short reg, unsigned char dat) {
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | (s * 0x20 + 0x08));//Write control byte through SPI, 1 byte data length, write data, select the register of port s
	SPI1_Send_Byte(dat);							//Write 1 byte of data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Write_W5500_SOCK_2Byte
 * Description: Write 2 bytes of data to the specified port register via SPI
 * Input: s: port number, reg: 16-bit register address, dat: 16-bit data to be written (2 bytes)
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_SOCK_2Byte(SOCKET s, unsigned short reg, unsigned short dat) {
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | (s * 0x20 + 0x08));//Write control byte through SPI, 2 bytes data length, write data, select the register of port s
	SPI1_Send_Short(dat);							//Write 1 byte of data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Write_W5500_SOCK_4Byte
 * Description: Write 4 bytes of data to the specified port register via SPI
 * Input: s: port number, reg: 16-bit register address, *dat_ptr: 4-byte buffer pointer to be written
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Write_W5500_SOCK_4Byte(SOCKET s, unsigned short reg,
		unsigned char *dat_ptr) {
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_WRITE | (s * 0x20 + 0x08));//Write control byte through SPI, 4 bytes data length, write data, select the register of port s

	SPI1_Send_Byte(*dat_ptr++);					//Write the first byte of data
	SPI1_Send_Byte(*dat_ptr++);						//Write the second byte data
	SPI1_Send_Byte(*dat_ptr++);						//Write the 3rd byte data
	SPI1_Send_Byte(*dat_ptr++);						//Write the 4th byte data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level
}

/*******************************************************************************
 * Function name: Read_W5500_1Byte
 * Description: Read 1 byte data of W5500 specified address register
 * input: reg: 16-bit register address
 * output: none
 * Return value: 1 byte of data read into the register
 * Description: none
 *******************************************************************************/
unsigned char Read_W5500_1Byte(unsigned short reg) {
	unsigned char i;

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level
	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_READ | COMMON_R);//Write control byte through SPI, 1 byte data length, read data, select general register
	i = hspi1.Instance->DR;						//Read 1 byte of data
	SPI1_Send_Byte(0x00);						//Send a dummy data
	i = hspi1.Instance->DR;						//Read 1 byte of data
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET);//Set the SCS of W5500 to high level
	return i;									//Return the read register data
}

/*******************************************************************************
 * Function name: Read_W5500_SOCK_1Byte
 * Description: Read 1 byte data of W5500 specified port register
 * Input: s: port number, reg: 16-bit register address
 * output: none
 * Return value: 1 byte of data read into the register
 * Description: none
 *******************************************************************************/
unsigned char Read_W5500_SOCK_1Byte(SOCKET s, unsigned short reg) {
	unsigned char i;

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_READ | (s * 0x20 + 0x08));	//Write control byte through SPI, 1 byte data length, read data, select the register of port s

	i = hspi1.Instance->DR;							//Read 1 byte of data
	SPI1_Send_Byte(0x00);							//Send a dummy data
	i = hspi1.Instance->DR;							//Read 1 byte of data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET);//Set the SCS of W5500 to high level
	return i;									//Return the read register data
}

/*******************************************************************************
 * Function name: Read_W5500_SOCK_2Byte
 * Description: Read 2 bytes data of W5500 specified port register
 * Input: s: port number, reg: 16-bit register address
 * output: none
 * Return value: 2 bytes of data (16 bits) read into the register
 * Description: none
 *******************************************************************************/
unsigned short Read_W5500_SOCK_2Byte(SOCKET s, unsigned short reg) {
	unsigned short i;

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(reg);			//Write 16-bit register address through SPI
	SPI1_Send_Byte(VDM | RWB_READ | (s * 0x20 + 0x08));	//Write control byte through SPI, 2 bytes data length, read data, select the register of port s

	i = hspi1.Instance->DR;
	SPI1_Send_Byte(0x00);							//Send a dummy data
	i = hspi1.Instance->DR;							//Read high data
	SPI1_Send_Byte(0x00);							//Send a dummy data
	i *= 256;
	i += hspi1.Instance->DR;							//Read low data

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET);//Set the SCS of W5500 to high level
	return i;									//Return the read register data
}

/*******************************************************************************
 * Function name: Read_SOCK_Data_Buffer
 * Description: Read data from W5500 receive data buffer
 * Input: s: port number, *dat_ptr: data storage buffer pointer
 * output: none
 * Return value: the length of the data read, rx_size bytes
 * Description: none
 *******************************************************************************/
unsigned short Read_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr) {
	unsigned short rx_size;
	unsigned short offset, offset1;
	unsigned short i;
	unsigned char j;

	rx_size = Read_W5500_SOCK_2Byte(s, Sn_RX_RSR);
	if (rx_size == 0)
		return 0;						//Return if no data is received
	if (rx_size > 1460)
		rx_size = 1460;

	offset = Read_W5500_SOCK_2Byte(s, Sn_RX_RD);
	offset1 = offset;
	offset &= (S_RX_SIZE - 1);			//Calculate the actual physical address

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set the SCS of W5500 to low level

	SPI1_Send_Short(offset);						//Write 16-bit address
	SPI1_Send_Byte(VDM | RWB_READ | (s * 0x20 + 0x18));	//Write control byte, N bytes data length, read data, select the register of port s
	j = hspi1.Instance->DR;

	if ((offset + rx_size) < S_RX_SIZE)	//If the maximum address does not exceed the maximum address of the W5500 receive buffer register
	{
		for (i = 0; i < rx_size; i++)		//loop to read rx_size bytes of data
				{
			SPI1_Send_Byte(0x00);					//Send a dummy data
			j = hspi1.Instance->DR;					//Read 1 byte of data
			*dat_ptr = j;		//Save the read data to the data storage buffer
			dat_ptr++;//The address of the data storage buffer pointer is incremented by 1
		}
	} else//If the maximum address exceeds the maximum address of the W5500 receive buffer register
	{
		offset = S_RX_SIZE - offset;
		for (i = 0; i < offset; i++)//loop to read out the first offset bytes of data
				{
			SPI1_Send_Byte(0x00);					//Send a dummy data
			j = hspi1.Instance->DR;					//Read 1 byte of data
			*dat_ptr = j;		//Save the read data to the data storage buffer
			dat_ptr++;//The address of the data storage buffer pointer is incremented by 1
		}
		HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level

		HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin,
				GPIO_PIN_RESET);	//Set the SCS of W5500 to low level

		SPI1_Send_Short(0x00);						//Write 16-bit address
		SPI1_Send_Byte(VDM | RWB_READ | (s * 0x20 + 0x18));	//Write control byte, N bytes data length, read data, select the register of port s
		j = hspi1.Instance->DR;

		for (; i < rx_size; i++)//Rx_size-offset bytes of data after loop reading
				{
			SPI1_Send_Byte(0x00);					//Send a dummy data
			j = hspi1.Instance->DR;					//Read 1 byte of data
			*dat_ptr = j;		//Save the read data to the data storage buffer
			dat_ptr++;//The address of the data storage buffer pointer is incremented by 1
		}
	}
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level

	offset1 += rx_size;	//Update the actual physical address, that is, the starting address of the received data next time read
	Write_W5500_SOCK_2Byte(s, Sn_RX_RD, offset1);
	Write_W5500_SOCK_1Byte(s, Sn_CR, RECV);		//Send start receiving command
	return rx_size;						//Return the length of the received data
}

/*******************************************************************************
 * º¯ÊýÃû  : Write_SOCK_Data_Buffer
 * ÃèÊö    : ½«Êý¾ÝÐ´ÈëW5500µÄÊý¾Ý·¢ËÍ»º³åÇø
 * ÊäÈë    : s:¶Ë¿ÚºÅ,*dat_ptr:Êý¾Ý±£´æ»º³åÇøÖ¸Õë,size:´ýÐ´ÈëÊý¾ÝµÄ³¤¶È
 * Êä³ö    : ÎÞ
 * ·µ»ØÖµ  : ÎÞ
 * ËµÃ÷    : ÎÞ
 *******************************************************************************/
void Write_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr,
		unsigned short size) {
	unsigned short offset, offset1;
	unsigned short i;

	//Èç¹ûÊÇUDPÄ£Ê½,¿ÉÒÔÔÚ´ËÉèÖÃÄ¿µÄÖ÷»úµÄIPºÍ¶Ë¿ÚºÅ
//	if((Read_W5500_SOCK_1Byte(s,Sn_MR)&0x0f) != SOCK_UDP)//Èç¹ûSocket´ò¿ªÊ§°Ü
//	{
//		Write_W5500_SOCK_4Byte(s, Sn_DIPR, UDP_DIPR);//ÉèÖÃÄ¿µÄÖ÷»úIP
//		Write_W5500_SOCK_2Byte(s, Sn_DPORTR, UDP_DPORT[0]*256+UDP_DPORT[1]);//ÉèÖÃÄ¿µÄÖ÷»ú¶Ë¿ÚºÅ
//	}

	offset = Read_W5500_SOCK_2Byte(s, Sn_TX_WR);
	offset1 = offset;
	offset &= (S_TX_SIZE - 1);								//¼ÆËãÊµ¼ÊµÄÎïÀíµØÖ·

	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_RESET);//Set SCS of W5500 to low level

	SPI1_Send_Short(offset);			 	//Ð´16Î»µØÖ·
	SPI1_Send_Byte(VDM | RWB_WRITE | (s * 0x20 + 0x10));//Ð´¿ØÖÆ×Ö½Ú,N¸ö×Ö½ÚÊý¾Ý³¤¶È,Ð´Êý¾Ý,Ñ¡Ôñ¶Ë¿ÚsµÄ¼Ä´æÆ÷

	if ((offset + size) < S_TX_SIZE)//Èç¹û×î´óµØÖ·Î´³¬¹ýW5500·¢ËÍ»º³åÇø¼Ä´æÆ÷µÄ×î´óµØÖ·
	{
		for (i = 0; i < size; i++)			 	//Ñ­»·Ð´Èësize¸ö×Ö½ÚÊý¾Ý
				{
			SPI1_Send_Byte(*dat_ptr++);			 	//Ð´ÈëÒ»¸ö×Ö½ÚµÄÊý¾Ý
		}
	} else			 	//Èç¹û×î´óµØÖ·³¬¹ýW5500·¢ËÍ»º³åÇø¼Ä´æÆ÷µÄ×î´óµØÖ·
	{
		offset = S_TX_SIZE - offset;
		for (i = 0; i < offset; i++)			 	//Ñ­»·Ð´ÈëÇ°offset¸ö×Ö½ÚÊý¾Ý
				{
			SPI1_Send_Byte(*dat_ptr++);			 	//Ð´ÈëÒ»¸ö×Ö½ÚµÄÊý¾Ý
		}
		HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level

		HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin,
				GPIO_PIN_RESET);		 	//Set SCS of W5500 to low level

		SPI1_Send_Short(0x00);		 	//Ð´16Î»µØÖ·
		SPI1_Send_Byte(VDM | RWB_WRITE | (s * 0x20 + 0x10));//Ð´¿ØÖÆ×Ö½Ú,N¸ö×Ö½ÚÊý¾Ý³¤¶È,Ð´Êý¾Ý,Ñ¡Ôñ¶Ë¿ÚsµÄ¼Ä´æÆ÷

		for (; i < size; i++)		 	//Ñ­»·Ð´Èësize-offset¸ö×Ö½ÚÊý¾Ý
				{
			SPI1_Send_Byte(*dat_ptr++);		 	//Ð´ÈëÒ»¸ö×Ö½ÚµÄÊý¾Ý
		}
	}
	HAL_GPIO_WritePin(SPI1_CS_NET_GPIO_Port, SPI1_CS_NET_Pin, GPIO_PIN_SET); //Set SCS of W5500 to high level

	offset1 += size; //¸üÐÂÊµ¼ÊÎïÀíµØÖ·,¼´ÏÂ´ÎÐ´´ý·¢ËÍÊý¾Ýµ½·¢ËÍÊý¾Ý»º³åÇøµÄÆðÊ¼µØÖ·
	Write_W5500_SOCK_2Byte(s, Sn_TX_WR, offset1);
	Write_W5500_SOCK_1Byte(s, Sn_CR, SEND); 			 	//·¢ËÍÆô¶¯·¢ËÍÃüÁî
}

/*******************************************************************************
 * Function name: W5500_Hardware_Reset
 * Description: Hardware reset W5500
 * input : none
 * output: none
 * Return value: none
 * Note: The reset pin of W5500 remains low for at least 500us before restarting W5500
 *******************************************************************************/
void W5500_Hardware_Reset(void) {
	HAL_GPIO_WritePin(W5500_RST_GPIO_Port, W5500_RST_Pin, GPIO_PIN_RESET);//Reset pin pulled low
	HAL_Delay(50);
	HAL_GPIO_WritePin(W5500_RST_GPIO_Port, W5500_RST_Pin, GPIO_PIN_SET);//Reset pin pulled high
	HAL_Delay(200);
	while ((Read_W5500_1Byte(PHYCFGR) & LINK) == 0)
		;						//Wait for the Ethernet connection to complete
}

/*******************************************************************************
 * Function name: W5500_Init
 * Description: Initialize W5500 register function
 * input : none
 * output: none
 * Return value: none
 * Note: Before using W5500, initialize W5500
 *******************************************************************************/
void W5500_Init(void) {
	unsigned short i = 0;

	Write_W5500_1Byte(MR, RST);	//Software reset W5500, set 1 to be valid, and automatically clear to 0 after reset
	HAL_Delay(10);							//Delay 10ms

	//Set the IP address of the gateway (Gateway), Gateway_IP is a 4-byte uint8_t array, define it yourself
	//Using the gateway can make the communication break through the limitation of the subnet, and you can access other subnets or enter the Internet through the gateway
	Write_W5500_nByte(GAR, Gateway_IP, 4);

	//Set the subnet mask (MASK) value, SUB_MASK is a 4-byte uint8_t array, define it yourself
	//Subnet mask is used for subnet operation
	Write_W5500_nByte(SUBR, Sub_Mask, 4);

	//Set the physical address, PHY_ADDR is a 6-byte uint8_t array, defined by yourself, used to uniquely identify the physical address value of the network device
	//The address value needs to be applied to IEEE. According to the regulations of OUI, the first three bytes are the manufacturer code, and the last three bytes are the product serial number.
	//If you define the physical address yourself, note that the first byte must be an even number
	Write_W5500_nByte(SHAR, Phy_Addr, 6);

	//Set the IP address of the machine, IP_ADDR is a 4-byte uint8_t array, define it yourself
	//Note that the gateway IP must belong to the same subnet as the local IP, otherwise the local machine will not be able to find the gateway
	Write_W5500_nByte(SIPR, IP_Addr, 4);

	//Set the size of the send buffer and receive buffer, refer to the W5500 data sheet
	for (i = 0; i < 8; i++) {
		Write_W5500_SOCK_1Byte(i, Sn_RXBUF_SIZE, 0x02);	//Socket Rx memory size=2k
		Write_W5500_SOCK_1Byte(i, Sn_TXBUF_SIZE, 0x02);	//Socket Tx mempry size=2k
	}

	//Set the retry time, the default is 2000 (200ms)
	//The value of each unit is 100 microseconds, and the value is set to 2000 (0x07D0) during initialization, which is equal to 200 milliseconds
	Write_W5500_2Byte(RTR, 0x07d0);

	//Set the number of retries, the default is 8
	//If the number of retransmissions exceeds the set value, a timeout interrupt will be generated (the Sn_IR timeout bit (TIMEOUT) in the relevant port interrupt register is set to "1")
	Write_W5500_1Byte(RCR, 8);
}

/*******************************************************************************
 * Function name: Detect_Gateway
 * Description: Check gateway server
 * input : none
 * output: none
 * Return value: TRUE (0xFF) if successful, FALSE (0x00) if failed
 * Description: none
 *******************************************************************************/
unsigned char Detect_Gateway(void) {
	unsigned char ip_adde[4];
	ip_adde[0] = IP_Addr[0] + 1;
	ip_adde[1] = IP_Addr[1] + 1;
	ip_adde[2] = IP_Addr[2] + 1;
	ip_adde[3] = IP_Addr[3] + 1;

	//Check the gateway and get the physical address of the gateway
	Write_W5500_SOCK_4Byte(0, Sn_DIPR, ip_adde);//Write an IP value different from the local IP to the destination address register
	Write_W5500_SOCK_1Byte(0, Sn_MR, MR_TCP);	//Set socket to TCP mode
	Write_W5500_SOCK_1Byte(0, Sn_CR, OPEN);	//Open Socket
	HAL_Delay(5);	//delay 5ms

	if (Read_W5500_SOCK_1Byte(0, Sn_SR) != SOCK_INIT)	//If socket open fails
	{
		Write_W5500_SOCK_1Byte(0, Sn_CR, CLOSE);//Open unsuccessful, close Socket
		return FALSE;	//return false
	}

	Write_W5500_SOCK_1Byte(0, Sn_CR, CONNECT);	//Set Socket to Connect mode

	do {
		unsigned short j = 0;
		j = Read_W5500_SOCK_1Byte(0, Sn_IR);//Read Socket0 interrupt flag register
		if (j != 0)
			Write_W5500_SOCK_1Byte(0, Sn_IR, j);
		HAL_Delay(5);	//delay 5ms
		if ((j & IR_TIMEOUT) == IR_TIMEOUT) {
			return FALSE;
		} else if (Read_W5500_SOCK_1Byte(0, Sn_DHAR) != 0xff) {
			Write_W5500_SOCK_1Byte(0, Sn_CR, CLOSE);	//close socket
			return TRUE;
		}
	} while (1);
}

/*******************************************************************************
 * Function name: Socket_Init
 * Description: Specify Socket(0~7) to initialize
 * input: s: port to be initialized
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void Socket_Init(SOCKET s) {
	//set specified port
	switch (s) {
	case 0:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(0, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 0
		Write_W5500_SOCK_2Byte(0, Sn_PORT, S0_Port[0] * 256 + S0_Port[1]);
		//Set the destination (remote) port number of port 0
		Write_W5500_SOCK_2Byte(0, Sn_DPORTR, S0_DPort[0] * 256 + S0_DPort[1]);
		//Set port 0 destination (remote) IP address
		Write_W5500_SOCK_4Byte(0, Sn_DIPR, S0_DIP);
		break;

	case 1:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(1, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 1
		Write_W5500_SOCK_2Byte(1, Sn_PORT, S1_Port[0] * 256 + S1_Port[1]);
		//Set the destination (remote) port number of port 0
		Write_W5500_SOCK_2Byte(1, Sn_DPORTR, S1_DPort[0] * 256 + S1_DPort[1]);
		//Set port 1 destination (remote) IP address
		Write_W5500_SOCK_4Byte(1, Sn_DIPR, S1_DIP);
		break;

	case 2:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(2, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 2
		Write_W5500_SOCK_2Byte(2, Sn_PORT, S2_Port[0] * 256 + S2_Port[1]);
		//Set the destination (remote) port number of port 2
		Write_W5500_SOCK_2Byte(2, Sn_DPORTR, S2_DPort[0] * 256 + S2_DPort[1]);
		//Set port 2 destination (remote) IP address
		Write_W5500_SOCK_4Byte(2, Sn_DIPR, S2_DIP);
		break;

	case 3:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(3, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 3
		Write_W5500_SOCK_2Byte(3, Sn_PORT, S3_Port[0] * 256 + S3_Port[1]);
		//Set the destination (remote) port number of port 3
		Write_W5500_SOCK_2Byte(3, Sn_DPORTR, S3_DPort[0] * 256 + S3_DPort[1]);
		//Set port 3 destination (remote) IP address
		Write_W5500_SOCK_4Byte(3, Sn_DIPR, S3_DIP);
		break;

	case 4:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(4, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 4
		Write_W5500_SOCK_2Byte(4, Sn_PORT, S4_Port[0] * 256 + S4_Port[1]);
		//Set the destination (remote) port number of port 4
		Write_W5500_SOCK_2Byte(4, Sn_DPORTR, S4_DPort[0] * 256 + S4_DPort[1]);
		//Set port 4 destination (remote) IP address
		Write_W5500_SOCK_4Byte(4, Sn_DIPR, S4_DIP);
		break;

	case 5:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(5, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 5
		Write_W5500_SOCK_2Byte(5, Sn_PORT, S5_Port[0] * 256 + S5_Port[1]);
		//Set the destination (remote) port number of port 5
		Write_W5500_SOCK_2Byte(5, Sn_DPORTR, S5_DPort[0] * 256 + S5_DPort[1]);
		//Set port 5 destination (remote) IP address
		Write_W5500_SOCK_4Byte(5, Sn_DIPR, S5_DIP);
		break;

	case 6:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(6, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 6
		Write_W5500_SOCK_2Byte(6, Sn_PORT, S6_Port[0] * 256 + S6_Port[1]);
		//Set the destination (remote) port number of port 6
		Write_W5500_SOCK_2Byte(6, Sn_DPORTR, S6_DPort[0] * 256 + S6_DPort[1]);
		//Set port 6 destination (remote) IP address
		Write_W5500_SOCK_4Byte(6, Sn_DIPR, S6_DIP);
		break;

	case 7:
		//Set the fragment length, refer to the W5500 data sheet, this value can not be modified
		Write_W5500_SOCK_2Byte(7, Sn_MSSR, 1460);//Maximum fragment bytes = 1460 (0x5b4)
		//Set the port number of port 7
		Write_W5500_SOCK_2Byte(7, Sn_PORT, S7_Port[0] * 256 + S7_Port[1]);
		//Set the destination (remote) port number of port 7
		Write_W5500_SOCK_2Byte(7, Sn_DPORTR, S7_DPort[0] * 256 + S7_DPort[1]);
		//Set port 7 destination (remote) IP address
		Write_W5500_SOCK_4Byte(7, Sn_DIPR, S7_DIP);
		break;

	default:
		break;
	}
}

/*******************************************************************************
 * Function name: Socket_Connect
 * Description: Set the specified Socket (0~7) for the client to connect with the remote server
 * Input: s: port to be set
 * output: none
 * Return value: TRUE (0xFF) if successful, FALSE (0x00) if failed
 * Description: When the native Socket works in client mode, refer to this program to establish a connection with the remote server
 * If there is a timeout interruption after starting the connection, the connection to the server fails, and the program needs to be re-called to connect
 * Every time the program is called, a connection is made with the server
 *******************************************************************************/
unsigned char Socket_Connect(SOCKET s) {
	Write_W5500_SOCK_1Byte(s, Sn_MR, MR_TCP);			//Set socket to TCP mode
	Write_W5500_SOCK_1Byte(s, Sn_CR, OPEN);			//Open Socket
	HAL_Delay(5);									//Delay 5ms
	if (Read_W5500_SOCK_1Byte(s, Sn_SR) != SOCK_INIT)//If the socket fails to open
	{
		Write_W5500_SOCK_1Byte(s, Sn_CR, CLOSE);//Unsuccessful opening, close Socket
		return FALSE;								//Return FALSE(0x00)
	}
	Write_W5500_SOCK_1Byte(s, Sn_CR, CONNECT);		//Set Socket to Connect mode
	return TRUE;						//Return TRUE, the setting is successful
}

/*******************************************************************************
 * Function name: Socket_Listen
 * Description: Set the specified Socket (0~7) as the server waiting for the connection of the remote host
 * Input: s: port to be set
 * output: none
 * Return value: TRUE (0xFF) if successful, FALSE (0x00) if failed
 * Description: When the native Socket works in server mode, refer to the program, etc. for the connection of the remote host
 * This program is called only once to make W5500 set to server mode
 *******************************************************************************/
unsigned char Socket_Listen(SOCKET s) {
	Write_W5500_SOCK_1Byte(s, Sn_MR, MR_TCP);			//Set socket to TCP mode
	Write_W5500_SOCK_1Byte(s, Sn_CR, OPEN);				//Open Socket
	HAL_Delay(5);
	if (Read_W5500_SOCK_1Byte(s, Sn_SR) != SOCK_INIT)//If the socket fails to open
	{
		Write_W5500_SOCK_1Byte(s, Sn_CR, CLOSE);//Unsuccessful opening, close Socket
		return FALSE;
	}
	Write_W5500_SOCK_1Byte(s, Sn_CR, LISTEN);	//Set Socket to listening mode
	HAL_Delay(5);
	if (Read_W5500_SOCK_1Byte(s, Sn_SR) != SOCK_LISTEN)	//If socket setting fails
	{
		Write_W5500_SOCK_1Byte(s, Sn_CR, CLOSE);//The setting is unsuccessful, close the Socket
		return FALSE;
	}

	return TRUE;

	//At this point, the opening of the Socket and the setting of the listening work are completed. As for whether
	//the remote client establishes a connection with it, it needs to wait for the Socket to be interrupted.
	//To determine whether the Socket connection is successful. Refer to Socket Interrupt Status of W5500 Datasheet
	//There is no need to set the destination IP and destination port number in the server listening mode
}

/*******************************************************************************
 * Function name: Socket_UDP
 * Description: Set the specified Socket (0~7) to UDP mode
 * Input: s: port to be set
 * output: none
 * Return value: TRUE (0xFF) if successful, FALSE (0x00) if failed
 * Description: If Socket works in UDP mode, refer to this program. In UDP mode, Socket communication does not need to establish a connection
 * This program is called only once, so that the W5500 is set to UDP mode
 *******************************************************************************/
unsigned char Socket_UDP(SOCKET s) {
	Write_W5500_SOCK_1Byte(s, Sn_MR, MR_UDP);			//Set Socket to UDP mode
	Write_W5500_SOCK_1Byte(s, Sn_CR, OPEN);				//Open Socket
	HAL_Delay(5);
	if (Read_W5500_SOCK_1Byte(s, Sn_SR) != SOCK_UDP)//If the socket fails to open
	{
		Write_W5500_SOCK_1Byte(s, Sn_CR, CLOSE);//Unsuccessful opening, close Socket
		return FALSE;
	} else
		return TRUE;

	//At this point, the opening of Socket and the setting of UDP mode are completed. In this mode, it does not
	//need to establish a connection with the remote host. Because the Socket does not need to establish a connection,
	//you can set the destination host IP and the port number of the destination Socket before sending data
	//If the destination host IP and the port number of the destination Socket are fixed and do not change during
	//operation, they can also be set here
}

/*******************************************************************************
 * Function name: W5500_Interrupt_Process
 * Description: W5500 Interrupt Handler Framework
 * input : none
 * output: none
 * Return value: none
 * Description: none
 *******************************************************************************/
void W5500_Interrupt_Process(void) {
	unsigned char i, j;

	IntDispose:

	i = Read_W5500_1Byte(SIR);	//Read the port interrupt flag register
	HAL_Delay(5);

	if ((i & S0_INT) == S0_INT)	//Socket0ÊÂ¼þ´¦Àí
	{
		j = Read_W5500_SOCK_1Byte(0, Sn_IR);	//¶ÁÈ¡Socket0ÖÐ¶Ï±êÖ¾¼Ä´æÆ÷
		Write_W5500_SOCK_1Byte(0, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)	//ÔÚTCPÄ£Ê½ÏÂ,Socket0³É¹¦Á¬½Ó
		{
			//printf("%x\r\n",IR_SEND_OK);
			S0_State |= S_CONN;	//ÍøÂçÁ¬½Ó×´Ì¬0x02,¶Ë¿ÚÍê³ÉÁ¬½Ó£¬¿ÉÒÔÕý³£´«ÊäÊý¾Ý
		}
		if (j & IR_DISCON)	//ÔÚTCPÄ£Ê½ÏÂSocket¶Ï¿ªÁ¬½Ó´¦Àí
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(0, Sn_CR, CLOSE);//¹Ø±Õ¶Ë¿Ú,µÈ´ýÖØÐÂ´ò¿ªÁ¬½Ó
			Socket_Init(0);		//Ö¸¶¨Socket(0~7)³õÊ¼»¯,³õÊ¼»¯¶Ë¿Ú0
			S0_State = 0;		//ÍøÂçÁ¬½Ó×´Ì¬0x00,¶Ë¿ÚÁ¬½ÓÊ§°Ü
		}
		if (j & IR_SEND_OK)	//Socket0Êý¾Ý·¢ËÍÍê³É,¿ÉÒÔÔÙ´ÎÆô¶¯S_tx_process()º¯Êý·¢ËÍÊý¾Ý
		{
			//printf("%x\r\n",IR_SEND_OK);
			S0_Data |= S_TRANSMITOK;		//¶Ë¿Ú·¢ËÍÒ»¸öÊý¾Ý°üÍê³É
		}
		if (j & IR_RECV)		//Socket½ÓÊÕµ½Êý¾Ý,¿ÉÒÔÆô¶¯S_rx_process()º¯Êý
		{
			//printf("%x\r\n",IR_RECV);
			S0_Data |= S_RECEIVE;		//¶Ë¿Ú½ÓÊÕµ½Ò»¸öÊý¾Ý°ü
		}
		if (j & IR_TIMEOUT)		//SocketÁ¬½Ó»òÊý¾Ý´«Êä³¬Ê±´¦Àí
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(0, Sn_CR, CLOSE);// ¹Ø±Õ¶Ë¿Ú,µÈ´ýÖØÐÂ´ò¿ªÁ¬½Ó
			S0_State = 0;		//ÍøÂçÁ¬½Ó×´Ì¬0x00,¶Ë¿ÚÁ¬½ÓÊ§°Ü
		}
	}

	if ((i & S1_INT) == S1_INT)		//Socket1 event handling
	{
		j = Read_W5500_SOCK_1Byte(1, Sn_IR);//Read Socket1 interrupt flag register
		Write_W5500_SOCK_1Byte(1, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket1 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S1_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(1, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(1);	//Specify Socket (0~7) initialization, initialize port 1
			S1_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S1_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S1_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(1, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S1_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S2_INT) == S2_INT)		//Socket2 event handling
	{
		j = Read_W5500_SOCK_1Byte(2, Sn_IR);//Read Socket2 interrupt flag register
		Write_W5500_SOCK_1Byte(2, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket2 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S2_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(2, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(2);	//Specify Socket (0~7) initialization, initialize port 2
			S2_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S2_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S2_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(2, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S2_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S3_INT) == S3_INT)		//Socket3 event handling
	{
		j = Read_W5500_SOCK_1Byte(3, Sn_IR);//Read Socket3 interrupt flag register
		Write_W5500_SOCK_1Byte(3, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket3 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S3_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(3, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(3);	//Specify Socket (0~7) initialization, initialize port 3
			S3_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S3_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S3_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(3, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S3_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S4_INT) == S4_INT)		//Socket4 event handling
	{
		j = Read_W5500_SOCK_1Byte(4, Sn_IR);//Read Socket4 interrupt flag register
		Write_W5500_SOCK_1Byte(4, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket4 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S4_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(4, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(4);	//Specify Socket (0~7) initialization, initialize port 4
			S4_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S4_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S4_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(4, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S4_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S5_INT) == S5_INT)		//Socket5 event handling
	{
		j = Read_W5500_SOCK_1Byte(5, Sn_IR);//Read Socket5 interrupt flag register
		Write_W5500_SOCK_1Byte(5, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket5 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S5_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(5, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(5);	//Specify Socket (0~7) initialization, initialize port 5
			S5_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S5_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S5_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(5, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S5_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S6_INT) == S6_INT)		//Socket6 event handling
	{
		j = Read_W5500_SOCK_1Byte(6, Sn_IR);//Read Socket6 interrupt flag register
		Write_W5500_SOCK_1Byte(6, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket6 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S6_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(6, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(6);	//Specify Socket (0~7) initialization, initialize port 6
			S6_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S6_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S6_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(6, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S6_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if ((i & S7_INT) == S7_INT)		//Socket7 event handling
	{
		j = Read_W5500_SOCK_1Byte(7, Sn_IR);//Read Socket7 interrupt flag register
		Write_W5500_SOCK_1Byte(7, Sn_IR, j);
		//printf("%c\r\n",j);
		if (j & IR_CON)		//In TCP mode, Socket7 connects successfully
		{
			//printf("%x\r\n",IR_SEND_OK);
			S7_State |= S_CONN;	//The network connection status is 0x02, the port is connected and the data can be transmitted normally
		}
		if (j & IR_DISCON)		//Socket disconnection handling in TCP mode
		{
			//printf("%x\r\n",IR_DISCON);
			Write_W5500_SOCK_1Byte(7, Sn_CR, CLOSE);//Close the port and wait for the connection to be reopened
			Socket_Init(7);	//Specify Socket (0~7) initialization, initialize port 7
			S7_State = 0;//Network connection status 0x00, port connection failed
		}
		if (j & IR_SEND_OK)	//Socket data transmission is completed, you can start the S_tx_process() function again to send data
		{
			//printf("%x\r\n",IR_SEND_OK);
			S7_Data |= S_TRANSMITOK;	//The port sends a packet to complete
		}
		if (j & IR_RECV)//Socket receives data and can start the S_rx_process() function
		{
			//printf("%x\r\n",IR_RECV);
			S7_Data |= S_RECEIVE;		//port received a packet
		}
		if (j & IR_TIMEOUT)	//Socket connection or data transmission timeout processing
		{
			//printf("%x\r\n",IR_TIMEOUT);
			Write_W5500_SOCK_1Byte(7, Sn_CR, CLOSE);// Close the port and wait for the connection to be reopened
			S7_State = 0;//Network connection status 0x00, port connection failed
		}
	}

	if (Read_W5500_1Byte(SIR) != 0)
		goto IntDispose;
}

