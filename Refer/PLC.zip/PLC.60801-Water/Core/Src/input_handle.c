/*
 * boardtests.c
 *
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 *
 *      Configure the Boards Parameter in the boardtest.h file
 */
#include "main.h"
#include "spi.h"

unsigned char SPI2_Read_Byte(void) {
	unsigned char i;
	HAL_SPI_Receive(&hspi2, &i, 1, 0xff);
	return i;
}

void Inputs_Handle(void) {

	HAL_GPIO_WritePin(SPI2_CS_INP1_GPIO_Port, SPI2_CS_INP1_Pin, GPIO_PIN_RESET);
	holding_register_value[InputWord1_addr] = SPI2_Read_Byte();
	HAL_GPIO_WritePin(SPI2_CS_INP1_GPIO_Port, SPI2_CS_INP1_Pin, GPIO_PIN_SET);
}
