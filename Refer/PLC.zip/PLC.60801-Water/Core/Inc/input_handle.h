/*
 * input_handle.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_INPUT_H_
#define SRC_INPUT_H_


unsigned char SPI2_Read_Byte(void);
unsigned short ReadInput(void);
void Inputs_Handle(void);

#endif /* SRC_INPUT_H_ */
