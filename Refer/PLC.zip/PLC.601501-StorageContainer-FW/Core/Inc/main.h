/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define NET_ID0_Pin GPIO_PIN_13
#define NET_ID0_GPIO_Port GPIOC
#define NET_ID1_Pin GPIO_PIN_14
#define NET_ID1_GPIO_Port GPIOC
#define NET_ID2_Pin GPIO_PIN_15
#define NET_ID2_GPIO_Port GPIOC
#define NET_ID3_Pin GPIO_PIN_0
#define NET_ID3_GPIO_Port GPIOC
#define COUNTER1_SIG_Pin GPIO_PIN_1
#define COUNTER1_SIG_GPIO_Port GPIOC
#define COUNTER2_SIG_Pin GPIO_PIN_2
#define COUNTER2_SIG_GPIO_Port GPIOC
#define RS485_DIR_Pin GPIO_PIN_3
#define RS485_DIR_GPIO_Port GPIOC
#define W5500_RST_Pin GPIO_PIN_4
#define W5500_RST_GPIO_Port GPIOA
#define SPI1_CS_NET_Pin GPIO_PIN_4
#define SPI1_CS_NET_GPIO_Port GPIOC
#define RS485_DIR_SL1_Pin GPIO_PIN_2
#define RS485_DIR_SL1_GPIO_Port GPIOB
#define IN_FAULT_Pin GPIO_PIN_6
#define IN_FAULT_GPIO_Port GPIOC
#define IN_READY_Pin GPIO_PIN_7
#define IN_READY_GPIO_Port GPIOC
#define IN_LATCH_Pin GPIO_PIN_8
#define IN_LATCH_GPIO_Port GPIOC
#define SPI2_CS_INP_Pin GPIO_PIN_9
#define SPI2_CS_INP_GPIO_Port GPIOC
#define OUT_RESET_Pin GPIO_PIN_8
#define OUT_RESET_GPIO_Port GPIOA
#define SPI2_CS_OUT_Pin GPIO_PIN_9
#define SPI2_CS_OUT_GPIO_Port GPIOA
#define OUT_FLAG_Pin GPIO_PIN_10
#define OUT_FLAG_GPIO_Port GPIOA
#define SPI2_CS_INP2_Pin GPIO_PIN_10
#define SPI2_CS_INP2_GPIO_Port GPIOC
#define SWB_TEMPS_Pin GPIO_PIN_5
#define SWB_TEMPS_GPIO_Port GPIOB
#define SPI2_CS_TMP_Pin GPIO_PIN_7
#define SPI2_CS_TMP_GPIO_Port GPIOB
#define LED_ERROR_Pin GPIO_PIN_8
#define LED_ERROR_GPIO_Port GPIOB
#define LED_ACT_Pin GPIO_PIN_9
#define LED_ACT_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

#define S0_PortNumber 502
#define S1_PortNumber 512
#define S2_PortNumber 522
#define S3_PortNumber 532
#define S4_PortNumber 542
#define S5_PortNumber 552
#define S6_PortNumber 562
#define S7_PortNumber 572

/***************** Modbus Function Codes *****************/

#define Read_Coils 0x01
#define Read_Discrete_Inputs 0x02
#define Read_Multiple_Holding_Registers 0x03
#define Read_Input_Registers 0x04
#define Wirte_Single_Coil 0x05
#define Write_Single_Holding_Register 0x06
#define Write_Multiple_Coils 0x0f
#define Write_Multiple_Holding_Register 0x10

/***************** Modbus Holding Registers *****************/

#define Manufacturer_addr 0
#define Manufacturer_val 2329

#define DeviceFamily_addr 1
#define DeviceFamily_val 6

#define DeviceType_addr 2
#define DeviceType_val 15

#define HardwareVersion_addr 3
#define HardwareVersion_val 1

#define SoftwareVersion_addr 4
#define SoftwareVersion_val 1

#define SerialNumber_addr 5

#define Built_Year_addr 6

#define Built_YOD_addr 7

#define MCUTemperature_addr 8

#define SecretKey_addr 9


#define InputWord1_addr 10
#define InputWord2_addr 11
#define InputWord3_addr 12
#define InputWord4_addr 13
#define InputWord5_addr 14


#define Inverter1_state_addr 15
#define Inverter2_state_addr 16

#define DeviceLocked_addr 17

#define CabinetTemperature_addr 18

#define CabinetOpen_addr 19

#define TemperatureProbe1_addr 20
#define TemperatureProbe2_addr 21
#define TemperatureProbe3_addr 22
#define TemperatureProbe4_addr 23
#define TemperatureProbe5_addr 24

#define TemperatureProbe1_Offset_addr 25
#define TemperatureProbe2_Offset_addr 26
#define TemperatureProbe3_Offset_addr 27
#define TemperatureProbe4_Offset_addr 28
#define TemperatureProbe5_Offset_addr 29

//Scale values as FLOAT (covering 2 registers)
#define Scale1_addr_1 30
#define Scale1_addr_2 31
#define Scale2_addr_1 32
#define Scale2_addr_2 33
#define Scale3_addr_1 34
#define Scale3_addr_2 35
#define Scale4_addr_1 36
#define Scale4_addr_2 37
#define Scale5_addr_1 38
#define Scale5_addr_2 39

//Counter values as LONG (covering 2 registers)
#define Counter1_addr 40
#define Counter1_addr_1 40
#define Counter1_addr_2 41
#define Counter2_addr 42
#define Counter3_addr 44
#define Counter4_addr 46
#define Counter5_addr 48

#define OutputWord1_addr 50
#define OutputWord2_addr 51
#define OutputWord3_addr 52
#define OutputWord4_addr 53
#define OutputWord5_addr 54

#define Inverter1_val_addr 55
#define Inverter1_cmd_addr 56
#define Inverter2_val_addr 57
#define Inverter2_cmd_addr 58

#define Scale_x_Preset_addr 60
#define Scale_x_Preset_addr_2 61
#define Counter_x_Preset_addr 62
#define Counter_x_Preset_addr_2 63
#define Counter_x_CalValue_addr 64
#define Counter_x_CalValue_addr_2 65

#define Scale_x_Index_addr 66
#define Scale_x_Cmd_addr 67
#define Counter_x_Index_addr 68
#define Counter_x_Cmd_addr 69

#define STA_SocketsActive_addr 80
#define STA_CylceTime_addr 81
#define BI_DI_Count_addr 82
#define BI_DO_Count_addr 83
#define BI_AI_Count_addr 84
#define BI_AO_Count_addr 85
#define BI_Temp_Count_addr 86
#define BI_Scale_Count_addr 87
#define BI_Counter_Count_addr 88
#define BI_Inverter_Count_addr 89
#define BI_IPSelector_addr 90
#define IPOffset_addr 91

#define Parameter1 100
#define Parameter2 101
#define Parameter3 102
#define Parameter4 103
#define Parameter5 104

#define SerialDeviceMode_None 0
#define SerialDeviceMode_TLB 10
#define SerialDeviceMode_CS80 20
#define SerialDeviceMode_Slave16 1016
#define SerialTimeoutDelay 200

void USART2_IRQHandler(void);

extern unsigned short holding_register_value[150];

#define ScaleMaxCount 5
#define InverterMaxCount 5

extern unsigned char rx_buffer_uart[200];
extern unsigned char scale_init_flag[ScaleMaxCount];
extern unsigned char scale_decimal[ScaleMaxCount];
extern unsigned char scale_activecmd[ScaleMaxCount];
extern float scale_values[ScaleMaxCount];

extern unsigned short inverter_activecmd[2];
extern unsigned short inverter_freqval[2];
extern unsigned char inverter_freq_setting_flag[2];

extern uint32_t serialTimeout;
extern int  serialDeviceMode;
extern uint8_t  serialIndex;
extern uint8_t  serialRXCounter;

extern uint8_t IPOffset;
extern uint8_t DeviceId;

#define EEPROM_Size 20
#define EEPROM_Starting_Address 0x0801FC00

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
