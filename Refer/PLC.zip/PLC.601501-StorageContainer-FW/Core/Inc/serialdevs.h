/*
 * scale.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_SERIALDEVS_H_
#define SRC_SERIALDEVS_H_

//Scale specific Infos

#define Read_Decimal 0x44
#define Read_Weight 0x74
#define Zero_Setting 0x7A
#define Calibration 0x73

//Functions

void Slave16_ProcessOutBuffer(void);
void Slave16_ProcessInbuffer(void);

char* TLB_AddCheckSum(char *data, int txtlen);
void TLB_ProcessOutBuffer(char scale_ID);
void TLB_ProcessInbuffer();

unsigned char* CS80_AddCheckSum(char *data, int txtlen);
void CS80_ProcessOutBuffer(char inverter_ID);
void CS80_ProcessInbuffer();

#endif /* SRC_SERIALDEVS_H_ */
