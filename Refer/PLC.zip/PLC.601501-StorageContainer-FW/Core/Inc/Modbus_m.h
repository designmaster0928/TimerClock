/*
 * Modbus.h
 *
 *  Created on: Oct 29, 2022
 *      Author: Developer
 */

#ifndef INC_MODBUS_H_
#define INC_MODBUS_H_

void Modbus_Process_master(unsigned int function_code, unsigned int startingAddress, unsigned int no_of_registers);

extern unsigned char Modbus_rtx[200];
extern int Modbus_rtx_len;


#endif /* INC_MODBUS_H_ */
