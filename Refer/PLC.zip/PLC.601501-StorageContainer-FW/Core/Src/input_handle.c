/*
 *
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 *
 */
#include "main.h"
#include "spi.h"
#include "usart.h"
#include "Modbus_m.h"

unsigned char SPI2_Read_Byte(void) {
	unsigned char i;
	HAL_SPI_Receive(&hspi2, &i, 1, 0xff);
	//HAL_SPI_TransmitReceive(&hspi2, 0x00, &i, 1, 0xff);
	return i;
}

unsigned char Byte_4Bit(unsigned char dat) {
	return (((dat & 0x40) >> 3) | ((dat & 0x10) >> 2) | ((dat & 0x04) >> 1)
			| (dat & 0x01));
}

unsigned char Byte_6Bit(unsigned char dat) {
	return (((dat & 0xF0) >> 2) | ((dat & 0x04) >> 1) | (dat & 0x01));
}

unsigned short ReadInput0(void) //Read Input
{
	unsigned char i, dat1, dat2;
	unsigned short input_state = 0;
	HAL_GPIO_WritePin(SPI2_CS_INP_GPIO_Port, SPI2_CS_INP_Pin,
				GPIO_PIN_RESET);
	dat1 = SPI2_Read_Byte();
	dat2 = SPI2_Read_Byte();
	HAL_GPIO_WritePin(SPI2_CS_INP_GPIO_Port, SPI2_CS_INP_Pin,
				GPIO_PIN_SET);
	input_state = dat1;
	return input_state;
}

unsigned short ReadInput(void) //Read Input
{
	unsigned char i, dat1, dat2, dat3, dat4, dat5, dat6, dat7, dat8;
	unsigned short input_state = 0;
	for (i = 0; i < 4; i++) {
		HAL_GPIO_WritePin(SPI2_CS_INP_GPIO_Port, SPI2_CS_INP_Pin,
				GPIO_PIN_RESET);
		dat1 = SPI2_Read_Byte();
		dat2 = SPI2_Read_Byte();
		dat3 = SPI2_Read_Byte();
		dat4 = SPI2_Read_Byte();
		dat5 = SPI2_Read_Byte();
		dat6 = SPI2_Read_Byte();
		dat7 = SPI2_Read_Byte();
		dat8 = SPI2_Read_Byte();
		HAL_GPIO_WritePin(SPI2_CS_INP_GPIO_Port, SPI2_CS_INP_Pin,
				GPIO_PIN_SET);
	}
	input_state = (Byte_4Bit(dat1) << 12) | (Byte_4Bit(dat3) << 8)
			| (Byte_4Bit(dat5) << 4) | (Byte_4Bit(dat7));
	return input_state;
}

unsigned short ReadInput2(void) //outputs control
{
	unsigned char i, dat1, dat2, dat3, dat4;
	unsigned short input2_state = 0;
	for (i = 0; i < 2; i++) {
		HAL_GPIO_WritePin(SPI2_CS_INP2_GPIO_Port, SPI2_CS_INP2_Pin,
				GPIO_PIN_RESET);
		dat1 = SPI2_Read_Byte();
		dat2 = SPI2_Read_Byte();
		dat3 = SPI2_Read_Byte();
		dat4 = SPI2_Read_Byte();
		HAL_GPIO_WritePin(SPI2_CS_INP2_GPIO_Port, SPI2_CS_INP2_Pin,
				GPIO_PIN_SET);
	}
	input2_state = ((dat1&0x0F)<<6) | (Byte_6Bit(dat3));
	return input2_state;
}

void Inputs_Handle(void) {
	holding_register_value[InputWord1_addr] = ReadInput0();
	//Modbus_Process_master(3, InputWord2_addr, 1);
}

