#include "main.h"
#include "usart.h"
#include "Modbus_m.h"

#define slaveID 1
unsigned char broadcastFlag;
unsigned char function;
unsigned int errorCount;

unsigned char Modbus_rtx[200] = { 0 };
int Modbus_rtx_len = 0;

// Modbus_rtx[] is used to recieve and transmit packages.
// The maximum serial ring Modbus_rtx_len  size is 128

// function definitions
void exceptionResponse(int exception);
unsigned int calculateCRC(int bufferSize);
void sendPacket(int bufferSize);

void Modbus_Process_master(unsigned int function_code, unsigned int startingAddress, unsigned int no_of_registers) {

	unsigned int maxData = startingAddress + no_of_registers;
	unsigned char index;
	unsigned char address;
	unsigned int crc16;

	Modbus_rtx[0]=slaveID;
	Modbus_rtx[1]=function_code;

	switch (function_code) {

		case 3:	//Read Multiple Holding registers
			Modbus_rtx[2]= (startingAddress >> 8) & 0xFF;
			Modbus_rtx[3]= (startingAddress) & 0xFF;
			Modbus_rtx[4]= (no_of_registers >> 8) & 0xFF;
			Modbus_rtx[5]= (no_of_registers) & 0xFF;

			crc16 = calculateCRC(4);
			Modbus_rtx[6]= (crc16 >> 8) & 0xFF;
			Modbus_rtx[7]= crc16 & 0xFF;
			sendPacket(8);
			break;

		case 6: //Write Single Holding register
			Modbus_rtx[2]= (startingAddress >> 8) & 0xFF;
			Modbus_rtx[3]= (startingAddress) & 0xFF;
			Modbus_rtx[4]= (holding_register_value[startingAddress] >> 8) & 0xFF;
			Modbus_rtx[5]= (holding_register_value[startingAddress]) & 0xFF;

			crc16 = calculateCRC(4);
			Modbus_rtx[6]= (crc16 >> 8) & 0xFF;
			Modbus_rtx[7]= crc16 & 0xFF;
			sendPacket(8);
			break;

		case 16: //Write Multiple Holding registers

			break;
		default:

			break;
	}
}

void exceptionResponse(int exception) {
	errorCount++; // each call to exceptionResponse() will increment the errorCount
	if (!broadcastFlag) { // don't respond if its a broadcast message
		Modbus_rtx[0] = slaveID;
		Modbus_rtx[1] = (function | 0x80); // set the MSB bit high, informs the master of an exception
		Modbus_rtx[2] = exception;
		unsigned int crc16 = calculateCRC(3); // ID, function + 0x80, exception code == 3 bytes
		Modbus_rtx[3] = crc16 >> 8;
		Modbus_rtx[4] = crc16 & 0xFF;
		sendPacket(5); // exception response is always 5 bytes ID, function + 0x80, exception code, 2 bytes crc
	}
}

unsigned int calculateCRC(int bufferSize) {
	unsigned int temp, temp2, flag;
	temp = 0xFFFF;
	for (unsigned char i = 0; i < bufferSize; i++) {
		temp = temp ^ Modbus_rtx[i];
		for (unsigned char j = 1; j <= 8; j++) {
			flag = temp & 0x0001;
			temp >>= 1;
			if (flag)
				temp ^= 0xA001;
		}
	}
	// Reverse byte order.
	temp2 = temp >> 8;
	temp = (temp << 8) | temp2;
	temp &= 0xFFFF;
	return temp; // the returned value is already swopped - crcLo byte is first & crcHi byte is last
}

void sendPacket(int bufferSize) {
	UART2_TransmitMessage_1(Modbus_rtx, bufferSize);
}
