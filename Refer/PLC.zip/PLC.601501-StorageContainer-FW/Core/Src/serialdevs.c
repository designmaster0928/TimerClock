/*
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 */
#include "usart.h"
#include "main.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <serialdevs.h>

void Slave16_ProcessOutBuffer(void) {
	if (holding_register_value[Parameter5] == 1) {
		//SLAVE is deactivated in config >> move forward to next device block
		serialIndex++;
		return;
	}

	unsigned char command[20] = { 0 };

	//basics
	command[0] = 0x02;					//STX (Start)
	command[1] = 'S';
	command[2] = '1';
	command[3] = '5';
	//transfer all 8 outputs of outputword2 to sub board
	command[4] = GetOutput(17) + 0x30;
	command[5] = GetOutput(18) + 0x30;
	command[6] = GetOutput(19) + 0x30;
	command[7] = GetOutput(20) + 0x30;
	command[8] = GetOutput(21) + 0x30;
	command[9] = GetOutput(22) + 0x30;
	command[10] = GetOutput(23) + 0x30;
	command[11] = GetOutput(24) + 0x30;
	command[12] = 0x03;					//ETX (End)
	command[13] = '\r';

	UART2_TransmitMessage_1(command, 14);
	HAL_GPIO_WritePin(RS485_DIR_GPIO_Port, RS485_DIR_Pin, GPIO_PIN_RESET);

	serialDeviceMode = SerialDeviceMode_Slave16;//set serial mode and timeout
	serialTimeout = HAL_GetTick();
}

void Slave16_ProcessInbuffer(void) {

	//process result here
	if ((rx_buffer_uart[0] == 0x2) && (rx_buffer_uart[1] == 'S')
			&& (rx_buffer_uart[2] == '1') && (rx_buffer_uart[3] == '6')
			&& (rx_buffer_uart[12] == 0x3)) {

		//inbound data stream is from a type 16 board
		//store buffer 4+5 like in send function in holding registers
		short temp_input = 0;
		for (int i = 4; i <= 11; i++) {
			temp_input = temp_input | (rx_buffer_uart[i] - 0x30) << (i - 4);
		}
		holding_register_value[InputWord2_addr] = temp_input;
	}

	holding_register_value[InputWord5_addr] = 0;
	serialDeviceMode = SerialDeviceMode_None;
	serialIndex++;
	serialTimeout = 0;
}

unsigned char* CS80_AddCheckSum(char *data, int txtlen) {
	char sChar;
	short nBCC1 = data[1];
	for (int i = 2; i <= txtlen; i++) {
		sChar = data[i];
		nBCC1 = nBCC1 + sChar;
	}
	return nBCC1 & 0xFF;
}

void CS80_ProcessOutBuffer(char inverter_ID) {

	if (holding_register_value[BI_Inverter_Count_addr] < inverter_ID) {
		//reached last Inverter >> move forward to next device block
		serialIndex = ScaleMaxCount + InverterMaxCount + 1;
		return;
	}

	inverter_freqval[0] = holding_register_value[Inverter1_val_addr];
	inverter_freqval[1] = holding_register_value[Inverter2_val_addr];

	int reqCmd = 0;
	unsigned char check_sum[3] = { 0 };
	unsigned char temp_checksum = 0;
	int commandlen = 1;
	unsigned char command[20] = { 0 };
	unsigned char freq_value[5] = { 0 };

	//basics
	command[0] = 0x05;					//ENQ (Start)
	command[1] = '0';					//Station 0
	command[2] = inverter_ID + 0x30;	//Station ID

	// select op mode outside of switch to not loose a cycle and prevent timeouts
	if (inverter_activecmd[inverter_ID - 1] == 2) {
		if (inverter_ID == 1) {
			reqCmd = holding_register_value[Inverter1_cmd_addr];
		} else {
			reqCmd = holding_register_value[Inverter2_cmd_addr];
		}

		if (reqCmd == 0)
			inverter_activecmd[inverter_ID - 1] = 10;
		if (reqCmd == 1)
			inverter_activecmd[inverter_ID - 1] = 11;
		if (reqCmd == 99)
			inverter_activecmd[inverter_ID - 1] = 12;
	}

	//switch states:
	switch (inverter_activecmd[inverter_ID - 1]) {

	case 0:	//transmit frequency

		command[3] = 'E';			//Command
		command[4] = 'D';			//Command
		command[5] = '1';			//Wating time

		//get the frequenecy
		itoa(inverter_freqval[inverter_ID - 1], freq_value, 16);
		//frequency is stored in modbus in 50Hz = 5000 - transmitted in hex
		if (inverter_freqval[inverter_ID - 1] < 16) {
			command[6] = '0';			//freq
			command[7] = '0';			//freq
			command[8] = '0';			//freq
			command[9] = toupper(freq_value[0]);		//freq

		} else if (inverter_freqval[inverter_ID - 1] < 256) {
			command[6] = '0';			//freq
			command[7] = '0';			//freq
			command[8] = toupper(freq_value[0]);		//freq
			command[9] = toupper(freq_value[1]);		//freq

		} else if (inverter_freqval[inverter_ID - 1] < 4096) {
			command[6] = '0';			//freq
			command[7] = toupper(freq_value[0]);		//freq
			command[8] = toupper(freq_value[1]);		//freq
			command[9] = toupper(freq_value[2]);		//freq

		} else {
			command[6] = toupper(freq_value[0]);		//freq
			command[7] = toupper(freq_value[1]);		//freq
			command[8] = toupper(freq_value[2]);		//freq
			command[9] = toupper(freq_value[3]);		//freq
		}

		//calculate checksum
		temp_checksum = CS80_AddCheckSum(command, 9);
		itoa(temp_checksum, check_sum, 16);
		if (temp_checksum < 16) {
			command[10] = '0';
			command[11] = toupper(check_sum[0]);
		} else {
			command[10] = toupper(check_sum[0]);
			command[11] = toupper(check_sum[1]);
		}
		command[12] = '\r';
		commandlen = 13;
		UART2_TransmitMessage_1(command, commandlen);
		break;

	case 1: //get current freq

		command[3] = '6';			//Command
		command[4] = 'F';			//Command
		command[5] = '1';			//wait

		temp_checksum = CS80_AddCheckSum(command, 5);
		itoa(temp_checksum, check_sum, 16);
		if (temp_checksum < 16) {
			command[6] = '0';
			command[7] = toupper(check_sum[0]);
		} else {
			command[6] = toupper(check_sum[0]);
			command[7] = toupper(check_sum[1]);
		}
		command[8] = '\r';
		commandlen = 9;
		UART2_TransmitMessage_1(command, commandlen);
		break;

	case 10: //inverter stop
		command[3] = 'F';			//Command
		command[4] = '9';			//Command
		command[5] = '1';			//wait
		command[6] = '0';			//STOP
		command[7] = '0';			//STOP
		command[8] = '0';			//STOP
		command[9] = '0';			//STOP

		//calculate checksum
		temp_checksum = CS80_AddCheckSum(command, 9);
		itoa(temp_checksum, check_sum, 16);
		if (temp_checksum < 16) {
			command[10] = '0';
			command[11] = toupper(check_sum[0]);
		} else {
			command[10] = toupper(check_sum[0]);
			command[11] = toupper(check_sum[1]);
		}
		command[12] = '\r';
		commandlen = 13;
		UART2_TransmitMessage_1(command, commandlen);
		inverter_freq_setting_flag[inverter_ID - 1] = 0;
		break;

	case 11:	// transmit run
		command[3] = 'F';			//Command
		command[4] = '9';			//Command
		command[5] = '1';			//wait
		command[6] = '0';			//RUN
		command[7] = '0';			//RUN
		command[8] = '0';			//RUN
		command[9] = '2';			//RUN

		//calculate checksum
		temp_checksum = CS80_AddCheckSum(command, 9);
		itoa(temp_checksum, check_sum, 16);
		if (temp_checksum < 16) {
			command[10] = '0';
			command[11] = toupper(check_sum[0]);
		} else {
			command[10] = toupper(check_sum[0]);
			command[11] = toupper(check_sum[1]);
		}
		command[12] = '\r';
		commandlen = 13;
		UART2_TransmitMessage_1(command, commandlen);
		break;

	case 12: //inverter reset
		command[3] = 'F';			//Command
		command[4] = 'D';			//Command
		command[5] = '1';			//wait
		command[6] = '0';			//Reset
		command[7] = '0';			//Reset
		command[8] = '0';			//Reset
		command[9] = '0';			//Reset

		//calculate checksum
		temp_checksum = CS80_AddCheckSum(command, 9);
		itoa(temp_checksum, check_sum, 16);
		if (temp_checksum < 16) {
			command[10] = '0';
			command[11] = toupper(check_sum[0]);
		} else {
			command[10] = toupper(check_sum[0]);
			command[11] = toupper(check_sum[1]);
		}
		command[12] = '\r';
		commandlen = 13;
		UART2_TransmitMessage_1(command, commandlen);
		inverter_freq_setting_flag[inverter_ID - 1] = 0;
		break;

	default:	//register out of alignment >> send back to 0
		inverter_activecmd[inverter_ID - 1] = 0;
		break;
	}

	HAL_GPIO_WritePin(RS485_DIR_GPIO_Port, RS485_DIR_Pin, GPIO_PIN_RESET);

	serialDeviceMode = SerialDeviceMode_CS80;	//set serial
	serialTimeout = HAL_GetTick();
}

void CS80_ProcessInbuffer() {
	char frequency_read[4] = { 0 };
	int inverterIndex = 0;

	inverterIndex = rx_buffer_uart[2] - 0x30; //locate which scale the response is from

	if (inverterIndex == 1 || inverterIndex == 2) {

		//switch inverter mode
		switch (inverter_activecmd[inverterIndex - 1]) {

		case 0: //responce to set freq
			inverter_activecmd[inverterIndex - 1] = 1;
			break;

		case 1: //response to get freq

			for (int i = 0; i < 4; i++) {
				if ((rx_buffer_uart[i + 3]) >= 0x30
						&& (rx_buffer_uart[i + 3]) <= 0x39) {
					frequency_read[i] = (rx_buffer_uart[i + 3]) - 0x30;
				} else if ((rx_buffer_uart[i + 3]) >= 0x41
						&& (rx_buffer_uart[i + 3]) <= 0x46) {
					frequency_read[i] = (rx_buffer_uart[i + 3]) - 0x37;
				}
			}

			if (inverterIndex == 1) {
				holding_register_value[Inverter1_state_addr] = frequency_read[0]
						<< 12 | frequency_read[1] << 8 | frequency_read[2] << 4
						| frequency_read[3];
			} else {
				holding_register_value[Inverter2_state_addr] = frequency_read[0]
						<< 12 | frequency_read[1] << 8 | frequency_read[2] << 4
						| frequency_read[3];
			}

			inverter_activecmd[inverterIndex - 1] = 2;
			break;

		case 10:  //inverter response for stop command
			inverter_activecmd[inverterIndex - 1] = 0;
			break;

		case 11:  //inverter response for run command
			inverter_activecmd[inverterIndex - 1] = 0;
			break;
		case 12:  //inverter response for freq reset command
			inverter_activecmd[inverterIndex - 1] = 0;
			break;
		}
	}

	//response handled - reset for next com cycle
	serialDeviceMode = SerialDeviceMode_None;
	serialIndex++;
	serialTimeout = 0;
}

char* TLB_AddCheckSum(char *data, int txtlen) {
	char sChar;
	char nBCC1 = data[1];
	for (int i = 2; i <= txtlen; i++) {
		sChar = data[i];
		nBCC1 = nBCC1 ^ sChar;
	}
	return nBCC1;
}

void TLB_ProcessOutBuffer(char scale_ID) {

	//if the scale channel is not enabled - RETURN
	if (holding_register_value[BI_Scale_Count_addr] < scale_ID) {
		//reached last scale >> move forward to next device block
		serialIndex = ScaleMaxCount + 1;
		return;
	}

	char scale_command[20] = { 0 };
	char check_sum[2] = { 0 };

	scale_command[0] = '$';
	scale_command[1] = '0';
	scale_command[2] = 0x30 + scale_ID;

	float scale_preset_f = 0;
	uint32_t scale_preset = 0;
	float scale_calweight = 0;
	char scale_calweight_byte[6] = { 0 };

	if (scale_init_flag[scale_ID - 1] != 1) {
		scale_command[3] = Read_Decimal;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = toupper(check_sum[0]);
		scale_command[5] = toupper(check_sum[1]);
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);

	} else if (holding_register_value[Scale_x_Index_addr] == scale_ID
			&& holding_register_value[Scale_x_Cmd_addr] == 10) {
		scale_command[3] = Zero_Setting;
		holding_register_value[Scale_x_Cmd_addr] = 0;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = toupper(check_sum[0]);
		scale_command[5] = toupper(check_sum[1]);
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);

	} else if (holding_register_value[Scale_x_Index_addr] == scale_ID
			&& holding_register_value[Scale_x_Cmd_addr] == 20) {
		scale_command[3] = Calibration;
		holding_register_value[Scale_x_Cmd_addr] = 0;

		scale_preset = holding_register_value[Scale_x_Preset_addr] << 16
				| holding_register_value[Scale_x_Preset_addr_2];
		scale_preset_f = *(float*) (&scale_preset);

		scale_calweight = (uint32_t) (scale_preset_f
				* pow(10, scale_decimal[scale_ID - 1]));

		itoa(scale_calweight, scale_calweight_byte, 10);

		if (scale_calweight < 10) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = '0';
			scale_command[8] = '0';
			scale_command[9] = scale_calweight_byte[0];

		} else if (scale_calweight < 100) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = '0';
			scale_command[8] = scale_calweight_byte[0];
			scale_command[9] = scale_calweight_byte[1];

		} else if (scale_calweight < 1000) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = scale_calweight_byte[0];
			scale_command[8] = scale_calweight_byte[1];
			scale_command[9] = scale_calweight_byte[2];

		} else if (scale_calweight < 10000) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = scale_calweight_byte[0];
			scale_command[7] = scale_calweight_byte[1];
			scale_command[8] = scale_calweight_byte[2];
			scale_command[9] = scale_calweight_byte[3];

		} else if (scale_calweight < 100000) {
			scale_command[4] = '0';
			scale_command[5] = scale_calweight_byte[0];
			scale_command[6] = scale_calweight_byte[1];
			scale_command[7] = scale_calweight_byte[2];
			scale_command[8] = scale_calweight_byte[3];
			scale_command[9] = scale_calweight_byte[4];

		} else {
			scale_command[4] = scale_calweight_byte[0];
			scale_command[5] = scale_calweight_byte[1];
			scale_command[6] = scale_calweight_byte[2];
			scale_command[7] = scale_calweight_byte[3];
			scale_command[8] = scale_calweight_byte[4];
			scale_command[9] = scale_calweight_byte[5];
		}

		itoa(TLB_AddCheckSum(scale_command, 9), check_sum, 16);

		scale_command[10] = toupper(check_sum[0]);
		scale_command[11] = toupper(check_sum[1]);
		scale_command[12] = '\r';
		UART2_TransmitMessage_1(scale_command, 13);
	} else {
		scale_command[3] = Read_Weight;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = check_sum[0];
		scale_command[5] = check_sum[1];
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);
	}

	//preserve last command issued to scale
	scale_activecmd[scale_ID - 1] = scale_command[3];

	serialDeviceMode = SerialDeviceMode_TLB;	//set serial
	serialTimeout = HAL_GetTick();

	HAL_GPIO_WritePin(RS485_DIR_GPIO_Port, RS485_DIR_Pin, GPIO_PIN_RESET);

	delay_ms(10);
}

void TLB_ProcessInbuffer() {
	//handle the inbound Data of the RS485

	char scale_weight[6] = { 0 };

	if ((rx_buffer_uart[0] == 0x26) && (rx_buffer_uart[1] != 0x26)
			&& (rx_buffer_uart[4] != 0x3F)) {

		int sclIndex = rx_buffer_uart[2] - 0x30; //locate which scale the response is from
		char sclMode = scale_activecmd[sclIndex - 1]; //restore last command issued

		//switch(scale_command[3])
		switch (sclMode) {

		case Read_Decimal:  //ASCII D
			scale_decimal[sclIndex - 1] = rx_buffer_uart[3] - 0x30;
			scale_init_flag[sclIndex - 1] = 1;
			break;

		case Read_Weight:  //ASCII t
			for (int i = 0; i < 6; i++) {
				scale_weight[i] = rx_buffer_uart[i + 3];
			}

			scale_values[sclIndex - 1] = atof(scale_weight)
					/ pow(10, scale_decimal[sclIndex - 1]);
			break;

		case Calibration:  //ASCII s
			break;

		case Zero_Setting:  //ASCII z
			break;

		default:
			break;
		}

		serialDeviceMode = SerialDeviceMode_None;
		serialIndex++;
		serialTimeout = 0;

	} else {
		//UART2_TransmitMessage("Error\r");
	}
}
