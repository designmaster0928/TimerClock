/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

#include <float.h>
#include <serialdevs.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Timer_Delay.h"
#include "tm_stm32_ds18b20.h"
#include "tm_stm32_onewire.h"

#include "Modbus_m.h"
#include "w5500.h"
#include "input_handle.h"
#include "output_handle.h"
#include "EEPROM_Handle.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t IPOffset;
uint8_t DeviceId;

//System
uint32_t netTimeout = 0;
uint32_t serialEndOfFrame = 0;

//Serial Port
uint32_t serialTimeout = 0;
int serialDeviceMode = SerialDeviceMode_None;
uint8_t serialIndex = 1;
uint8_t serialRXCounter = 0;
unsigned char rx_buffer_uart[200] = { 0 };

unsigned short holding_register_value[150];

uint32_t EEPROM_data[EEPROM_Size];

unsigned char scale_init_flag[5] = { 0 };
unsigned char scale_decimal[5] = { 0 };
unsigned char scale_activecmd[5] = { 0 };
float scale_values[5] = { 0 };

unsigned short inverter_activecmd[2] = { 0 };
unsigned short inverter_freqval[2] = { 0 };
unsigned char inverter_freq_setting_flag[2] = { 0 };

uint32_t cycletimer;

/* Onewire structure */
TM_OneWire_t OW;

/* Array for DS18B20 ROM number */
uint8_t DS_ROM[8];
uint8_t DS_ROM2[8];

/* Temperature variable */
float temp = 0;
float temp2 = 0;

/* Temperature variable */
uint8_t ds18b20_temp_sensor = 0;

/* USER CODE END PV */

void SystemClock_Config(void);

void Load_Net_Parameters(void);
void W5500_Initialization(void);
void W5500_Socket_Set(void);
void Process_Socket_Data(SOCKET s);
void GetStationSwitch(void);
float FilterValue(float newInput, float lastOutput, float efectiveFactor);

void TempProbe_init(void);
void TempProbe_Handle(void);

int GetInput(int inp);

void PublishBIInfo(void) {
	holding_register_value[BI_DI_Count_addr] = 8;
	holding_register_value[BI_DO_Count_addr] = 12;
	holding_register_value[BI_AI_Count_addr] = 0;
	holding_register_value[BI_AO_Count_addr] = 0;
	holding_register_value[BI_Temp_Count_addr] = 1;
	holding_register_value[BI_Counter_Count_addr] = 0;

	if (holding_register_value[BI_Scale_Count_addr] > 5
			|| holding_register_value[BI_Scale_Count_addr] < 0)
		holding_register_value[BI_Scale_Count_addr] = 0;
	if (holding_register_value[BI_Inverter_Count_addr] > 2
			|| holding_register_value[BI_Inverter_Count_addr] < 0)
		holding_register_value[BI_Inverter_Count_addr] = 0;
}

void HoldingRegister_Init(void) //holding register init
{
	holding_register_value[Manufacturer_addr] = Manufacturer_val;
	holding_register_value[DeviceFamily_addr] = DeviceFamily_val;
	holding_register_value[DeviceType_addr] = DeviceType_val;
	holding_register_value[HardwareVersion_addr] = HardwareVersion_val;
	holding_register_value[SoftwareVersion_addr] = SoftwareVersion_val;
	holding_register_value[SerialNumber_addr] = EEPROM_data[2];
	holding_register_value[Built_Year_addr] = EEPROM_data[3];
	holding_register_value[Built_YOD_addr] = EEPROM_data[4];
	holding_register_value[MCUTemperature_addr] = 0;
	holding_register_value[SecretKey_addr] = 0;
	holding_register_value[InputWord1_addr] = 0;
	holding_register_value[InputWord2_addr] = 0;
	holding_register_value[InputWord3_addr] = 0;
	holding_register_value[InputWord4_addr] = 0;
	holding_register_value[InputWord5_addr] = 0;
	holding_register_value[DeviceLocked_addr] = 0;
	holding_register_value[CabinetTemperature_addr] = 0;
	holding_register_value[CabinetOpen_addr] = 0;
	holding_register_value[TemperatureProbe1_addr] = 0;
	holding_register_value[TemperatureProbe2_addr] = 0;
	holding_register_value[TemperatureProbe3_addr] = 0;
	holding_register_value[TemperatureProbe4_addr] = 0;
	holding_register_value[TemperatureProbe5_addr] = 0;
	holding_register_value[TemperatureProbe1_Offset_addr] = EEPROM_data[5];
	holding_register_value[TemperatureProbe2_Offset_addr] = EEPROM_data[6];
	holding_register_value[TemperatureProbe3_Offset_addr] = EEPROM_data[7];
	holding_register_value[TemperatureProbe4_Offset_addr] = EEPROM_data[8];
	holding_register_value[TemperatureProbe5_Offset_addr] = EEPROM_data[9];
	holding_register_value[Scale1_addr_1] = 0;
	holding_register_value[Scale1_addr_2] = 0;
	holding_register_value[Scale2_addr_1] = 0;
	holding_register_value[Scale2_addr_2] = 0;
	holding_register_value[Scale3_addr_1] = 0;
	holding_register_value[Scale3_addr_2] = 0;
	holding_register_value[Scale4_addr_1] = 0;
	holding_register_value[Scale4_addr_2] = 0;
	holding_register_value[Scale5_addr_1] = 0;
	holding_register_value[Scale5_addr_2] = 0;
	holding_register_value[Counter1_addr] = 0;
	holding_register_value[Counter2_addr] = 0;
	holding_register_value[Counter3_addr] = 0;
	holding_register_value[Counter4_addr] = 0;
	holding_register_value[Counter5_addr] = 0;
	holding_register_value[OutputWord1_addr] = 0;
	holding_register_value[OutputWord2_addr] = 0;
	holding_register_value[OutputWord3_addr] = 0;
	holding_register_value[OutputWord4_addr] = 0;
	holding_register_value[OutputWord5_addr] = 0;
	holding_register_value[Scale_x_Preset_addr] = 0;
	holding_register_value[Scale_x_Preset_addr_2] = 0;
	holding_register_value[Counter_x_Preset_addr] = 0;
	holding_register_value[Scale_x_Index_addr] = 0;
	holding_register_value[Scale_x_Cmd_addr] = 0;
	holding_register_value[Counter_x_Index_addr] = 0;
	holding_register_value[Counter_x_Cmd_addr] = 0;

	holding_register_value[IPOffset_addr] = EEPROM_data[1];
	holding_register_value[STA_SocketsActive_addr] = 0;
	holding_register_value[STA_CylceTime_addr] = 0;
	holding_register_value[BI_Scale_Count_addr] = EEPROM_data[10];
	holding_register_value[BI_Inverter_Count_addr] = EEPROM_data[11];

	holding_register_value[Counter_x_CalValue_addr] = EEPROM_data[12];
	holding_register_value[Counter_x_CalValue_addr_2] = EEPROM_data[13];

	holding_register_value[Parameter1] = EEPROM_data[14];
	holding_register_value[Parameter2] = EEPROM_data[15];
	holding_register_value[Parameter3] = EEPROM_data[16];
	holding_register_value[Parameter4] = EEPROM_data[17];
	holding_register_value[Parameter5] = EEPROM_data[18];

	PublishBIInfo();
}

void USART2_IRQHandler(void) {
	__HAL_UART_DISABLE_IT(&huart2, UART_IT_RXNE);

	if (serialRXCounter == 0 || serialRXCounter > 198) {
		memset(rx_buffer_uart, 0, sizeof(rx_buffer_uart));
		serialRXCounter = 0;
	}

	//inbound data - add to rec buffer
	rx_buffer_uart[serialRXCounter++] = (&huart2)->Instance->DR;
	if ((&huart2)->Instance->DR == '\r') {
		if (serialDeviceMode == SerialDeviceMode_TLB) {
			TLB_ProcessInbuffer();
		}

		if (serialDeviceMode == SerialDeviceMode_CS80) {
			CS80_ProcessInbuffer();
		}

		if (serialDeviceMode == SerialDeviceMode_Slave16) {
			Slave16_ProcessInbuffer();
		}

		serialRXCounter = 0;
	}
	__HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
}

int main(void) {
	HAL_Init();
	SystemClock_Config();

	MX_GPIO_Init();
	MX_SPI1_Init();
	MX_SPI2_Init();
	MX_USART2_UART_Init();
	//MX_USART3_UART_Init();

	//MX_TIM2_Init();
//	HAL_TIM_Base_Start_IT(&htim2);

	TimerDelay_Init();
	TempProbe_init();

	memset(holding_register_value, 0, 300);
	memset(Rx_Buffer, 0, 2048);
	memset(Tx_Buffer, 0, 2048);

	memset(scale_init_flag, 0, sizeof(scale_init_flag));
	memset(scale_decimal, 0, sizeof(scale_activecmd));
	memset(scale_activecmd, 0, sizeof(scale_activecmd));
	memset(rx_buffer_uart, 0, sizeof(rx_buffer_uart));
	memset(scale_values, 0, sizeof(scale_values));

	UART2_TransmitMessage("DBG Starting\r\n");
	Flash_Read_Data(EEPROM_Starting_Address, (uint32_t*) EEPROM_data,
	EEPROM_Size);

	//if EEPROM does not contain manufacterer Code
	//board has never been configured, set to minimal viable parameters;
	//for runtime
	if (EEPROM_data[0] != Manufacturer_val) {
		memset(EEPROM_data, 0, sizeof(EEPROM_data));
		EEPROM_data[0] = Manufacturer_val;
		EEPROM_data[1] = 80;
	}
	IPOffset = EEPROM_data[1];

	UART2_TransmitMessage("DBG Flash read\r\n");
	HoldingRegister_Init();
	UART2_TransmitMessage("DBG Holding Registers configured\r\n");
	Load_Net_Parameters();
	UART2_TransmitMessage("DBG Net Parameters read\r\n");
	W5500_Hardware_Reset();
	UART2_TransmitMessage("DBG W5500 Hardware reset\r\n");
	W5500_Initialization();
	UART2_TransmitMessage("DBG W500 init done\r\n");

	__HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
	//__HAL_UART_ENABLE_IT(&huart3, UART_IT_RXNE);

	while (1) {

		cycletimer = HAL_GetTick();
		TempProbe_Handle();
		Outputs_Handle();
		Inputs_Handle();

//		if ((HAL_GetTick() - serialEndOfFrame) >= 3) {
//			//create transfer data to Modbus Block
//			memcpy(Modbus_rtx, rx_buffer_uart, sizeof(rx_buffer_uart));
//			Modbus_rtx_len = serialRXCounter;
//			serialRXCounter = 0;
//		}
//
//		//Modbus Buffer len > 0 so process the data
//		if (Modbus_rtx_len > 0) {		//process inbound stream
//			//Modbus_Process();
//			Modbus_rtx_len = 0;
//		}

		W5500_Socket_Set();			//W5500 port initial configuration
		W5500_Interrupt_Process();	//W5500 Interrupt Handler Framework

		if ((S0_Data & S_RECEIVE) == S_RECEIVE)	//If Socket0 receives data
		{
			S0_Data &= ~S_RECEIVE;
			Process_Socket_Data(0);	//W5500 receives and transmits received data
		}

		if ((S1_Data & S_RECEIVE) == S_RECEIVE)	//If Socket1 receives data
		{
			S1_Data &= ~S_RECEIVE;
			Process_Socket_Data(1);	//W5500 receives and transmits received data
		}

		if ((S2_Data & S_RECEIVE) == S_RECEIVE)	//If Socket2 receives data
		{
			S2_Data &= ~S_RECEIVE;
			Process_Socket_Data(2);	//W5500 receives and transmits received data
		}

		if ((S3_Data & S_RECEIVE) == S_RECEIVE)	//If Socket3 receives data
		{
			S3_Data &= ~S_RECEIVE;
			Process_Socket_Data(3);	//W5500 receives and transmits received data
		}

		if ((S4_Data & S_RECEIVE) == S_RECEIVE)	//If Socket4 receives data
		{
			S4_Data &= ~S_RECEIVE;
			Process_Socket_Data(4);	//W5500 receives and transmits received data
		}

		if ((S5_Data & S_RECEIVE) == S_RECEIVE)	//If Socket5 receives data
		{
			S5_Data &= ~S_RECEIVE;
			Process_Socket_Data(5);	//W5500 receives and transmits received data
		}

		if ((S6_Data & S_RECEIVE) == S_RECEIVE)	//If Socket6 receives data
		{
			S6_Data &= ~S_RECEIVE;
			Process_Socket_Data(6);	//W5500 receives and transmits received data
		}

		if ((S7_Data & S_RECEIVE) == S_RECEIVE)	//If Socket7 receives data
		{
			S7_Data &= ~S_RECEIVE;
			Process_Socket_Data(7);	//W5500 receives and transmits received data
		}

		//publish board info and override any nonsense that might have come in.
		PublishBIInfo();

		//Process Socket did not run for at least 2s
		if ((HAL_GetTick() - netTimeout) >= 1000) {
			HAL_GPIO_WritePin(LED_ACT_GPIO_Port, LED_ACT_Pin, GPIO_PIN_RESET);
		}

		//any of the board inputs in fault condition?
		if (GetInput(1) == 1 || GetInput(2) == 1 || GetInput(6) == 1)
			HAL_GPIO_WritePin(LED_ERROR_GPIO_Port, LED_ERROR_Pin, GPIO_PIN_SET);
		else
			HAL_GPIO_WritePin(LED_ERROR_GPIO_Port, LED_ERROR_Pin,
					GPIO_PIN_RESET);

		GetStationSwitch();

		//Communcation timed out >> RESET!
		if (serialDeviceMode != SerialDeviceMode_None) {
			if ((HAL_GetTick() - serialTimeout) >= SerialTimeoutDelay) {

				//reset device to requery setup and mark channel with -9999.99
				if (serialDeviceMode == SerialDeviceMode_TLB) {
					scale_init_flag[serialIndex - 1] = 0;
					scale_values[serialIndex - 1] = -9999.99;
				}

				//reset handling for CS80
				if (serialDeviceMode == SerialDeviceMode_CS80) {
					inverter_freq_setting_flag[serialIndex - ScaleMaxCount] = 0;
				}

				//Slave board is OFFLINE
				if (serialDeviceMode == SerialDeviceMode_Slave16) {
					holding_register_value[InputWord5_addr] = 1;
				}

				//reset communication area and move to next device
				serialIndex++;
				serialDeviceMode = SerialDeviceMode_None;
				serialRXCounter = 0;
				memset(rx_buffer_uart, 0, sizeof(rx_buffer_uart));
			}
		}

		//limit serial devices to 10
		if (serialIndex > 11)
			serialIndex = 1;

		//handle serial devices
		if (serialDeviceMode == SerialDeviceMode_None) {
			// scales
			if (serialIndex <= ScaleMaxCount)
				TLB_ProcessOutBuffer(serialIndex);
			// inverters
			if (serialIndex >= ScaleMaxCount)
				CS80_ProcessOutBuffer(serialIndex - ScaleMaxCount);

			if (serialIndex == ScaleMaxCount + InverterMaxCount + 1) {
				Slave16_ProcessOutBuffer();
			}

			//serialIndex is incremented by the RECEIVE function of the device
			//specific receive function or by gerneric COM timeout
		}

		//transfer the SCALE values to the modbus system for all channels
		for (int i = 0; i <= ScaleMaxCount - 1; i++) {
			uint16_t scale_data[2] = { 0 };
			memcpy(scale_data, &scale_values[i], sizeof(scale_data));
			holding_register_value[Scale1_addr_1 + ((i) << 1)] = scale_data[1];
			holding_register_value[Scale1_addr_2 + ((i) << 1)] = scale_data[0];
		}

		short cycle = HAL_GetTick() - cycletimer;
		holding_register_value[STA_CylceTime_addr] = (short) FilterValue(cycle,
				holding_register_value[STA_CylceTime_addr], 0.2f);
	}
}

void RSetFloat(int RegOffset, float value) {
	uint16_t val_data[2] = { 0 };
	memcpy(val_data, &value, sizeof(val_data));
	holding_register_value[RegOffset] = val_data[1];
	holding_register_value[RegOffset + 1] = val_data[0];
}

float RGetFloat(int RegOffset) {
	uint32_t val = holding_register_value[RegOffset] << 16
			| holding_register_value[RegOffset + 1];
	return *(float*) (&val);
}

uint32_t RGetLong(int RegOffset) {
	uint32_t val = holding_register_value[RegOffset] << 16
			| holding_register_value[RegOffset + 1];
	return val;
}

void RSetLong(int RegOffset, uint32_t value) {
	uint16_t val_data[2] = { 0 };
	memcpy(val_data, &value, sizeof(val_data));
	holding_register_value[RegOffset] = val_data[1];
	holding_register_value[RegOffset + 1] = val_data[0];

}
void SetOutput(int out) {
	uint16_t output_set = 0;
	if (out <= 16) {
		output_set = 1 << (out - 1);
		holding_register_value[OutputWord1_addr] =
				holding_register_value[OutputWord1_addr] | output_set;
	} else if (out > 16 && out <= 32) {
		output_set = 1 << (out - 17);
		holding_register_value[OutputWord2_addr] =
				holding_register_value[OutputWord2_addr] | output_set;
	} else if (out > 32 && out <= 48) {
		output_set = 1 << (out - 33);
		holding_register_value[OutputWord3_addr] =
				holding_register_value[OutputWord3_addr] | output_set;
	} else if (out > 48 && out <= 64) {
		output_set = 1 << (out - 49);
		holding_register_value[OutputWord4_addr] =
				holding_register_value[OutputWord4_addr] | output_set;
	} else {
		output_set = 1 << (out - 65);
		holding_register_value[OutputWord5_addr] =
				holding_register_value[OutputWord5_addr] | output_set;
	}

}
void ClearOutput(int out) {
	uint16_t output_set = 0;
	if (out <= 16) {
		output_set = 0xffff - (1 << (out - 1));
		holding_register_value[OutputWord1_addr] =
				holding_register_value[OutputWord1_addr] & output_set;
	} else if (out > 16 && out <= 32) {
		output_set = 0xffff - (1 << (out - 17));
		holding_register_value[OutputWord2_addr] =
				holding_register_value[OutputWord2_addr] & output_set;
	} else if (out > 32 && out <= 48) {
		output_set = 0xffff - (1 << (out - 33));
		holding_register_value[OutputWord3_addr] =
				holding_register_value[OutputWord3_addr] & output_set;
	} else if (out > 48 && out <= 64) {
		output_set = 0xffff - (1 << (out - 49));
		holding_register_value[OutputWord4_addr] =
				holding_register_value[OutputWord4_addr] & output_set;
	} else {
		output_set = 0xffff - (1 << (out - 65));
		holding_register_value[OutputWord5_addr] =
				holding_register_value[OutputWord5_addr] & output_set;
	}

}

int GetInput(int inp) {
	//returns 0 when off and 1 when on
	if (inp <= 16) {
		return (holding_register_value[InputWord1_addr] >> (inp - 1)) & 0x01;
	} else if (inp > 16 && inp <= 32) {
		return (holding_register_value[InputWord2_addr] >> (inp - 17)) & 0x01;
	} else if (inp > 32 && inp <= 48) {
		return (holding_register_value[InputWord3_addr] >> (inp - 33)) & 0x01;
	} else if (inp > 48 && inp <= 64) {
		return (holding_register_value[InputWord4_addr] >> (inp - 49)) & 0x01;
	} else {
		return (holding_register_value[InputWord5_addr] >> (inp - 65)) & 0x01;
	}
}

short GetOutput(int out) {
	//returns 0 when off and 1 when on
	if (out <= 16) {
		return (holding_register_value[OutputWord1_addr] >> (out - 1)) & 0x01;
	} else if (out > 16 && out <= 32) {
		return (holding_register_value[OutputWord2_addr] >> (out - 17)) & 0x01;
	} else if (out > 32 && out <= 48) {
		return (holding_register_value[OutputWord3_addr] >> (out - 33)) & 0x01;
	} else if (out > 48 && out <= 64) {
		return (holding_register_value[OutputWord4_addr] >> (out - 49)) & 0x01;
	} else {
		return (holding_register_value[OutputWord5_addr] >> (out - 65)) & 0x01;
	}
}

void TempProbe_init(void) {

	memset(DS_ROM, 0, sizeof(DS_ROM));
	memset(DS_ROM2, 0, sizeof(DS_ROM2));
	/* Init ONEWIRE port on PB5 pin */
	TM_OneWire_Init(&OW, SWB_TEMPS_GPIO_Port, SWB_TEMPS_Pin);

	/* Check if any device is connected */
	if (TM_OneWire_First(&OW)) {
		ds18b20_temp_sensor++;
		/* Read ROM number */
		TM_OneWire_GetFullROM(&OW, DS_ROM);
		if (TM_OneWire_Next(&OW)) {
			ds18b20_temp_sensor++;
			TM_OneWire_GetFullROM(&OW, DS_ROM2);
		} else {
		}
	} else {
	}

	/* Start temp conversion */
	if (TM_DS18B20_Is(DS_ROM)) {
		/* Set resolution */
		TM_DS18B20_SetResolution(&OW, DS_ROM, TM_DS18B20_Resolution_12bits);

		/* Set high and low alarms */
		TM_DS18B20_SetAlarmHighTemperature(&OW, DS_ROM, 50);
		TM_DS18B20_SetAlarmLowTemperature(&OW, DS_ROM, 0);

		/* Start conversion on all sensors */
		TM_DS18B20_Start(&OW, DS_ROM);
	}

	if (TM_DS18B20_Is(DS_ROM2)) {
		/* Set resolution */
		TM_DS18B20_SetResolution(&OW, DS_ROM2, TM_DS18B20_Resolution_12bits);

		/* Set high and low alarms */
		TM_DS18B20_SetAlarmHighTemperature(&OW, DS_ROM2, 50);
		TM_DS18B20_SetAlarmLowTemperature(&OW, DS_ROM2, 0);

		/* Start conversion on all sensors */
		TM_DS18B20_Start(&OW, DS_ROM2);
	}
}

void TempProbe_Handle(void) {

	if (TM_DS18B20_AllDone(&OW)) {
		/* Read temperature from device */
		if (TM_DS18B20_Read(&OW, DS_ROM, &temp)) {
			/* Temp read OK, CRC is OK */
			/* Start again on all sensors */
			//TM_DS18B20_Start(&OW, DS_ROM);
		} else {
			/* CRC failed, hardware problems on data line */
			temp = -999.9;
		}
		if (TM_DS18B20_Read(&OW, DS_ROM2, &temp2)) {
			/* Temp read OK, CRC is OK */
			/* Start again on all sensors */
			//TM_DS18B20_Start(&OW, DS_ROM2);
		} else {
			/* CRC failed, hardware problems on data line */
			temp2 = -999.9;
		}
		TM_DS18B20_StartAll(&OW);
	}

	holding_register_value[TemperatureProbe1_addr] = (temp * 10)
			- holding_register_value[TemperatureProbe1_Offset_addr];
	holding_register_value[TemperatureProbe2_addr] = (temp2 * 10)
			- holding_register_value[TemperatureProbe2_Offset_addr];

	holding_register_value[CabinetTemperature_addr] =
			holding_register_value[TemperatureProbe1_addr];

}

void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
		Error_Handler();
	}
}

void W5500_Initialization(void) {
	W5500_Init();		//Initialize W5500 register function
	Detect_Gateway();	//Check gateway server
	Socket_Init(0);		//Specify Socket (0~7) initialization, initialize port 0
	Socket_Init(1);		//Specify Socket (0~7) initialization, initialize port 1
	Socket_Init(2);		//Specify Socket (0~7) initialization, initialize port 2
	Socket_Init(3);		//Specify Socket (0~7) initialization, initialize port 3
	Socket_Init(4);		//Specify Socket (0~7) initialization, initialize port 4
	Socket_Init(5);		//Specify Socket (0~7) initialization, initialize port 7
	Socket_Init(6);		//Specify Socket (0~7) initialization, initialize port 6
	Socket_Init(7);		//Specify Socket (0~7) initialization, initialize port 7
}

void GetStationSwitch(void) {
	int swt = 0;
	if (HAL_GPIO_ReadPin(NET_ID0_GPIO_Port, NET_ID0_Pin) == 0)
		swt = swt + 1;
	if (HAL_GPIO_ReadPin(NET_ID1_GPIO_Port, NET_ID1_Pin) == 0)
		swt = swt + 2;
	if (HAL_GPIO_ReadPin(NET_ID2_GPIO_Port, NET_ID2_Pin) == 0)
		swt = swt + 4;
	if (HAL_GPIO_ReadPin(NET_ID3_GPIO_Port, NET_ID3_Pin) == 0)
		swt = swt + 8;
	holding_register_value[BI_IPSelector_addr] = swt;
}

void Load_Net_Parameters(void) {
	DeviceId = 0;
	if (HAL_GPIO_ReadPin(NET_ID0_GPIO_Port, NET_ID0_Pin) == 0)
		DeviceId = DeviceId + 1;
	if (HAL_GPIO_ReadPin(NET_ID1_GPIO_Port, NET_ID1_Pin) == 0)
		DeviceId = DeviceId + 2;
	if (HAL_GPIO_ReadPin(NET_ID2_GPIO_Port, NET_ID2_Pin) == 0)
		DeviceId = DeviceId + 4;
	if (HAL_GPIO_ReadPin(NET_ID3_GPIO_Port, NET_ID3_Pin) == 0)
		DeviceId = DeviceId + 8;

	Gateway_IP[0] = 192;		//�������ز���
	Gateway_IP[1] = 168;
	Gateway_IP[2] = 10;
	Gateway_IP[3] = 1;

	Sub_Mask[0] = 255;		//������������
	Sub_Mask[1] = 255;
	Sub_Mask[2] = 255;
	Sub_Mask[3] = 0;

	Phy_Addr[0] = 0x0c;		//����������ַ
	Phy_Addr[1] = 0x29;
	Phy_Addr[2] = 0xab;
	Phy_Addr[3] = 0x7c;
	Phy_Addr[4] = 0x00;
	Phy_Addr[5] = IPOffset + DeviceId;

	IP_Addr[0] = 192;		//���ر���IP��ַ
	IP_Addr[1] = 168;
	IP_Addr[2] = 10;
	IP_Addr[3] = IPOffset + DeviceId;

	S0_Port[0] = S0_PortNumber >> 8;
	S0_Port[1] = S0_PortNumber & 0xff;

	S1_Port[0] = S1_PortNumber >> 8;
	S1_Port[1] = S1_PortNumber & 0xff;

	S2_Port[0] = S2_PortNumber >> 8;
	S2_Port[1] = S2_PortNumber & 0xff;

	S3_Port[0] = S3_PortNumber >> 8;
	S3_Port[1] = S3_PortNumber & 0xff;

	S4_Port[0] = S4_PortNumber >> 8;
	S4_Port[1] = S4_PortNumber & 0xff;

	S5_Port[0] = S5_PortNumber >> 8;
	S5_Port[1] = S5_PortNumber & 0xff;

	S6_Port[0] = S6_PortNumber >> 8;
	S6_Port[1] = S6_PortNumber & 0xff;

	S7_Port[0] = S7_PortNumber >> 8;
	S7_Port[1] = S7_PortNumber & 0xff;

//	S0_DIP[0]=192;//���ض˿�0��Ŀ��IP��ַ
//	S0_DIP[1]=168;
//	S0_DIP[2]=10;
//	S0_DIP[3]=85;
//
//	S0_DPort[0] = 0x17;//���ض˿�0��Ŀ�Ķ˿ں�6000
//	S0_DPort[1] = 0x70;

	S0_Mode = TCP_SERVER;	//Load the working mode of port 0, TCP server mode
	S1_Mode = TCP_SERVER;	//Load the working mode of port 1, TCP server mode
	S2_Mode = TCP_SERVER;	//Load the working mode of port 2, TCP server mode
	S3_Mode = TCP_SERVER;	//Load the working mode of port 3, TCP server mode
	S4_Mode = TCP_SERVER;	//Load the working mode of port 4, TCP server mode
	S5_Mode = TCP_SERVER;	//Load the working mode of port 5, TCP server mode
	S6_Mode = TCP_SERVER;	//Load the working mode of port 6, TCP server mode
	S7_Mode = TCP_SERVER;	//Load the working mode of port 7, TCP server mode
}

void W5500_Socket_Set(void) {
	if (S0_State == 0)		//Port 0 initial configuration
			{
		if (S0_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(0) == TRUE)
				S0_State = S_INIT;
			else
				S0_State = 0;
		} else if (S0_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(0) == TRUE)
				S0_State = S_INIT;
			else
				S0_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(0) == TRUE)
				S0_State = S_INIT | S_CONN;
			else
				S0_State = 0;
		}
	}

	if (S1_State == 0)		//Port 1 initial configuration
			{
		if (S1_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(1) == TRUE)
				S1_State = S_INIT;
			else
				S1_State = 0;
		} else if (S1_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(1) == TRUE)
				S1_State = S_INIT;
			else
				S1_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(1) == TRUE)
				S1_State = S_INIT | S_CONN;
			else
				S1_State = 0;
		}
	}

	if (S2_State == 0)		//Port 2 initial configuration
			{
		if (S2_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(2) == TRUE)
				S2_State = S_INIT;
			else
				S2_State = 0;
		} else if (S2_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(2) == TRUE)
				S2_State = S_INIT;
			else
				S2_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(2) == TRUE)
				S2_State = S_INIT | S_CONN;
			else
				S2_State = 0;
		}
	}

	if (S3_State == 0)		//Port 3 initial configuration
			{
		if (S3_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(3) == TRUE)
				S3_State = S_INIT;
			else
				S3_State = 0;
		} else if (S3_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(3) == TRUE)
				S3_State = S_INIT;
			else
				S3_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(3) == TRUE)
				S3_State = S_INIT | S_CONN;
			else
				S3_State = 0;
		}
	}

	if (S4_State == 0)		//Port 4 initial configuration
			{
		if (S4_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(4) == TRUE)
				S4_State = S_INIT;
			else
				S4_State = 0;
		} else if (S4_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(4) == TRUE)
				S4_State = S_INIT;
			else
				S4_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(4) == TRUE)
				S4_State = S_INIT | S_CONN;
			else
				S4_State = 0;
		}
	}

	if (S5_State == 0)		//Port 5 initial configuration
			{
		if (S5_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(5) == TRUE)
				S5_State = S_INIT;
			else
				S5_State = 0;
		} else if (S5_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(5) == TRUE)
				S5_State = S_INIT;
			else
				S5_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(5) == TRUE)
				S5_State = S_INIT | S_CONN;
			else
				S5_State = 0;
		}
	}

	if (S6_State == 0)		//Port 6 initial configuration
			{
		if (S6_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(6) == TRUE)
				S6_State = S_INIT;
			else
				S6_State = 0;
		} else if (S6_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(6) == TRUE)
				S6_State = S_INIT;
			else
				S6_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(6) == TRUE)
				S6_State = S_INIT | S_CONN;
			else
				S6_State = 0;
		}
	}

	if (S7_State == 0)		//Port 7 initial configuration
			{
		if (S7_Mode == TCP_SERVER)		//TCP server mode
		{
			if (Socket_Listen(7) == TRUE)
				S7_State = S_INIT;
			else
				S7_State = 0;
		} else if (S7_Mode == TCP_CLIENT)		//TCP�ͻ���ģʽ
		{
			if (Socket_Connect(7) == TRUE)
				S7_State = S_INIT;
			else
				S7_State = 0;
		} else		//UDPģʽ
		{
			if (Socket_UDP(7) == TRUE)
				S7_State = S_INIT | S_CONN;
			else
				S7_State = 0;
		}
	}
}

void Process_Socket_Data(SOCKET s) {

	int msg_len;
	int i = 0;
	unsigned char msg[2048];
	msg_len = sizeof(msg);
	memset(msg, 0, msg_len);

	uint16_t coils_num = 0;
	uint16_t coil_address = 0;
	uint16_t register_num = 0;
	uint16_t register_address = 0;
	uint16_t coil_state = 0;
	uint16_t coil_update = 0;

	unsigned short size;
	size = Read_SOCK_Data_Buffer(s, Rx_Buffer);

	//if (Rx_Buffer[6] == DeviceId) Modbus IP target always configured to 1
	if (Rx_Buffer[6] == 1) {
		switch (Rx_Buffer[7]) {
		case 0x01:
			//UART2_TransmitMessage("function_code_1");
			coils_num = Rx_Buffer[10] << 8 | Rx_Buffer[11];
			msg[8] = (coils_num - 1) / 8 + 1;

			coil_address = Rx_Buffer[8] << 8 | Rx_Buffer[9];

			for (i = 0; i < msg[8]; i++) {
				msg[9 + i] = (holding_register_value[OutputWord1_addr]
						>> coil_address) >> (8 * i);
			}
			msg_len = 10 + msg[8];
			break;
		case 0x02:
			//UART2_TransmitMessage("function_code_2");

			coils_num = Rx_Buffer[10] << 8 | Rx_Buffer[11];
			msg[8] = (coils_num - 1) / 8 + 1;

			coil_address = Rx_Buffer[8] << 8 | Rx_Buffer[9];

			for (i = 0; i < msg[8]; i++) {
				msg[9 + i] = (holding_register_value[InputWord1_addr]
						>> coil_address) >> (8 * i);
			}
			msg_len = 10 + msg[8];
			break;
		case 0x03:
			//UART2_TransmitMessage("function_code_3");
			register_num = Rx_Buffer[10] << 8 | Rx_Buffer[11];
			register_address = Rx_Buffer[8] << 8 | Rx_Buffer[9];
			msg[8] = register_num << 1;

			for (i = 0; i < register_num; i++) {
				msg[9 + i * 2] = (holding_register_value[register_address + i])
						>> 8;
				msg[10 + i * 2] = (holding_register_value[register_address + i])
						& 0xff;
			}
			msg_len = 9 + msg[8];
			break;
		case 0x04:
			//UART2_TransmitMessage("function_code_4");
			break;
		case 0x05:
			//UART2_TransmitMessage("function_code_5");
			coil_address = Rx_Buffer[8] << 8 | Rx_Buffer[9];
			coil_state = Rx_Buffer[10] << 8 | Rx_Buffer[11];

			if (coil_state == 0xff00) {
				coil_update = 1 << coil_address;
				holding_register_value[OutputWord1_addr] =
						holding_register_value[OutputWord1_addr]
								| (coil_update);
			} else if (coil_state == 0x0000) {
				coil_update = 0xffff - (1 << coil_address);
				holding_register_value[OutputWord1_addr] =
						holding_register_value[OutputWord1_addr]
								& (coil_update);
			}

			msg[8] = Rx_Buffer[8];
			msg[9] = Rx_Buffer[9];
			msg[10] = Rx_Buffer[10];
			msg[11] = Rx_Buffer[11];
			msg_len = 12;
			break;
		case 0x06:
			//UART2_TransmitMessage("function_code_6");
			holding_register_value[Rx_Buffer[8] << 8 | Rx_Buffer[9]] =
					Rx_Buffer[10] << 8 | Rx_Buffer[11];
			msg[8] = Rx_Buffer[8];
			msg[9] = Rx_Buffer[9];
			msg[10] = Rx_Buffer[10];
			msg[11] = Rx_Buffer[11];
			msg_len = 12;

			if (holding_register_value[SecretKey_addr] == 2329) {
				Flash_update();
			}
			break;
		case 0x0f:
			//UART2_TransmitMessage("function_code_15");
			coils_num = Rx_Buffer[10] << 8 | Rx_Buffer[11];
			coil_address = Rx_Buffer[8] << 8 | Rx_Buffer[9];

			for (i = 0; i < Rx_Buffer[12]; i++) {
				coil_state = coil_state << (8 * i) | Rx_Buffer[13 + i];
			}

			coil_update = coil_state << coil_address;
			holding_register_value[OutputWord1_addr] = coil_update;

			msg[8] = Rx_Buffer[8];
			msg[9] = Rx_Buffer[9];
			msg[10] = Rx_Buffer[10];
			msg[11] = Rx_Buffer[11];
			msg_len = 12;
			break;
		case 0x10:
			//UART2_TransmitMessage("function_code_16");
			register_num = Rx_Buffer[10] << 8 | Rx_Buffer[11];
			for (i = 0; i < register_num; i++) {
				holding_register_value[(Rx_Buffer[8] << 8 | Rx_Buffer[9]) + i] =
						Rx_Buffer[13 + i * 2] << 8 | Rx_Buffer[14 + i * 2];
			}
			msg[8] = Rx_Buffer[8];
			msg[9] = Rx_Buffer[9];
			msg[10] = Rx_Buffer[10];
			msg[11] = Rx_Buffer[11];
			msg_len = 12;

			if (holding_register_value[SecretKey_addr] == 2329) {
				Flash_update();
			}

			break;
		default:
			break;
		}
	}

	msg[0] = Rx_Buffer[0];
	msg[1] = Rx_Buffer[1];
	msg[2] = 0x00;
	msg[3] = 0x00;
	msg[4] = 0x00;
	msg[5] = msg_len - 0x06;
	msg[6] = Rx_Buffer[6];
	msg[7] = Rx_Buffer[7];

	memcpy(Tx_Buffer, msg, msg_len);
	Write_SOCK_Data_Buffer(s, Tx_Buffer, msg_len);

	//set activity LED due to recent activity
	HAL_GPIO_WritePin(LED_ACT_GPIO_Port, LED_ACT_Pin, GPIO_PIN_SET);
	netTimeout = HAL_GetTick();
}

float FilterValue(float newInput, float lastOutput, float efectiveFactor) {
	return (lastOutput * (1.0f - efectiveFactor)) + (newInput * efectiveFactor);
}

void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
