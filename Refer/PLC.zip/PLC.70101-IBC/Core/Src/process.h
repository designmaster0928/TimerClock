/*
 * process.h
 *
 *  Created on: Oct 4, 2022
 *      Author: Developer
 */

#ifndef SRC_PROCESS_H_
#define SRC_PROCESS_H_

#define RegOffset_Dev1 250
#define RegOffset_Dev2 500
#define DeviceBlockLength 220

#define RegOffset_Reservtaion1 110
#define RegOffset_Reservtaion2 140
#define ReservationSlots 10

#define  CFG_MaxLoad_addr    0
#define  CFG_MinFlow_addr    4
#define  CFG_MinFlowTime_addr    36
#define  CFG_CalFactor_addr    92
#define  CFG_CalWeight_addr    200
#define  CFG_FilterFactor_addr    96
#define  CFG_Chg_Sub_addr    24
#define  CFG_Chg_Stab_addr    20
#define  CFG_DCh_Sub_addr    32
#define  CFG_DCh_Stab_addr    28
#define  CFG_DCh_Prestop_addr    8
#define  CTR_StartCharge_addr    60
#define  CTR_StopCharge_addr    61
#define  CTR_StartDischarge_addr    62
#define  CTR_StopDischarge_addr    63
#define  CTR_SubStart_addr    64
#define  CTR_SubStop_addr    65
#define  CTR_ProcessEnd_addr    66
#define  CTR_SetCalZero_addr    204
#define  CTR_SetCalWeight_addr    205
#define  PRD_Quantity_addr    41
#define  PRD_PreStop_addr    45
#define  PRD_Fine_addr    49
#define  PRD_Source_addr    57
#define  PRD_Destination_addr    58
#define  PRD_Temperature_addr    53
#define  STA_Step_Charge_addr    75
#define  STA_Step_Discharge_addr    76
#define  STA_Step_Misc_addr    77
#define  STA_JobSpeed_addr    71
#define  STA_Weight_addr    84
#define  STA_TotalWeight_addr    88
#define  STA_Temp_addr    67
#define  STA_MatError_addr    82
#define  STA_Error_addr    81
#define  STA_Charging_addr    78
#define  STA_Discharging_addr    79
#define  STA_ManualDischargeOverride_addr    83
#define  STA_MISC_addr    80
#define  STA_ScaleFault_addr    206
#define  STA_ScaleStable_addr    207
#define  STA_ScaleDynamic_addr    208
#define  INF_IngredNr_addr    100
#define  INF_IngredName_addr    110
#define  INF_IngredTrack_addr    180
#define  INF_RecipeNr_addr    140
#define  INF_RecipeName_addr    150
#define  INF_RecipeTrack_addr    190


extern float scale_TareMemory[5];
extern float dosingSpeed[5];
extern long timers[20];


//Functions
void ReservationManager(int regOffset);
void ProcessTank(int Tank, int regOffset);
int GetValveState(int val);

#endif /* SRC_PROCESS_H_ */
