/*
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 */
#include "usart.h"
#include "main.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <serialdevs.h>

void CS80_ProcessOutBuffer(char inverter_ID){

	if (holding_register_value[BI_Inverter_Count_addr] < inverter_ID)
	{
		//reached last Inverter >> move forward to next device block
		serialIndex = ScaleMaxCount + InverterMaxCount + 1;
		return;
	}

	//process inverter data here
	serialIndex++;
}

char* TLB_AddCheckSum(char *data, int txtlen) {
	char sChar;
	char nBCC1 = data[1];
	for (int i = 2; i <= txtlen; i++) {
		sChar = data[i];
		nBCC1 = nBCC1 ^ sChar;
	}
	return nBCC1;
}

void TLB_ProcessOutBuffer(char scale_ID) {


	//if the scale channel is not enabled - RETURN
	if (holding_register_value[BI_Scale_Count_addr] < scale_ID)
	{
		//reached last scale >> move forward to next device block
		serialIndex = ScaleMaxCount + 1;
		return;
	}

	char scale_command[20] = { 0 };
	char check_sum[2] = { 0 };

	scale_command[0] = '$';
	scale_command[1] = '0';
	scale_command[2] = 0x30 + scale_ID;

	float scale_preset_f = 0;
	uint32_t scale_preset = 0;
	float scale_calweight = 0;
	char scale_calweight_byte[6] = { 0 };

	if (scale_init_flag[scale_ID - 1] != 1) {
		scale_command[3] = Read_Decimal;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = toupper(check_sum[0]);
		scale_command[5] = toupper(check_sum[1]);
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);

	} else if (holding_register_value[Scale_x_Index_addr] == scale_ID
			&& holding_register_value[Scale_x_Cmd_addr] == 10) {
		scale_command[3] = Zero_Setting;
		holding_register_value[Scale_x_Cmd_addr] = 0;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = toupper(check_sum[0]);
		scale_command[5] = toupper(check_sum[1]);
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);

	} else if (holding_register_value[Scale_x_Index_addr] == scale_ID
			&& holding_register_value[Scale_x_Cmd_addr] == 20) {
		scale_command[3] = Calibration;
		holding_register_value[Scale_x_Cmd_addr] = 0;

		scale_preset = holding_register_value[Scale_x_Preset_addr] << 16
				| holding_register_value[Scale_x_Preset_addr_2];
		scale_preset_f = *(float*) (&scale_preset);

		scale_calweight = (uint32_t) (scale_preset_f
				* pow(10, scale_decimal[scale_ID - 1]));

		itoa(scale_calweight, scale_calweight_byte, 10);

		if (scale_calweight < 10) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = '0';
			scale_command[8] = '0';
			scale_command[9] = scale_calweight_byte[0];

		} else if (scale_calweight < 100) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = '0';
			scale_command[8] = scale_calweight_byte[0];
			scale_command[9] = scale_calweight_byte[1];

		} else if (scale_calweight < 1000) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = '0';
			scale_command[7] = scale_calweight_byte[0];
			scale_command[8] = scale_calweight_byte[1];
			scale_command[9] = scale_calweight_byte[2];

		} else if (scale_calweight < 10000) {
			scale_command[4] = '0';
			scale_command[5] = '0';
			scale_command[6] = scale_calweight_byte[0];
			scale_command[7] = scale_calweight_byte[1];
			scale_command[8] = scale_calweight_byte[2];
			scale_command[9] = scale_calweight_byte[3];

		} else if (scale_calweight < 100000) {
			scale_command[4] = '0';
			scale_command[5] = scale_calweight_byte[0];
			scale_command[6] = scale_calweight_byte[1];
			scale_command[7] = scale_calweight_byte[2];
			scale_command[8] = scale_calweight_byte[3];
			scale_command[9] = scale_calweight_byte[4];

		} else {
			scale_command[4] = scale_calweight_byte[0];
			scale_command[5] = scale_calweight_byte[1];
			scale_command[6] = scale_calweight_byte[2];
			scale_command[7] = scale_calweight_byte[3];
			scale_command[8] = scale_calweight_byte[4];
			scale_command[9] = scale_calweight_byte[5];
		}

		itoa(TLB_AddCheckSum(scale_command, 9), check_sum, 16);

		scale_command[10] = toupper(check_sum[0]);
		scale_command[11] = toupper(check_sum[1]);
		scale_command[12] = '\r';
		UART2_TransmitMessage_1(scale_command, 13);
	} else {
		scale_command[3] = Read_Weight;

		itoa(TLB_AddCheckSum(scale_command, 3), check_sum, 16);

		scale_command[4] = check_sum[0];
		scale_command[5] = check_sum[1];
		scale_command[6] = '\r';

		UART2_TransmitMessage_1(scale_command, 7);
	}

	//preserve last command issued to scale
	scale_activecmd[scale_ID - 1] = scale_command[3];

	serialDeviceMode = SerialDeviceMode_TLB;	//set serial
	serialTimeout = HAL_GetTick();

	HAL_GPIO_WritePin(RS485_DIR_GPIO_Port, RS485_DIR_Pin, GPIO_PIN_RESET);

	delay_ms(10);
}

void TLB_ProcessInbuffer() {
	//handle the inbound Data of the RS485

	char scale_weight[6] = { 0 };
//	float scale_data_f;
//	uint16_t scale_data[2] = { 0 };

	if ((rx_buffer_uart[0] == 0x26) && (rx_buffer_uart[1] != 0x26)
			&& (rx_buffer_uart[4] != 0x3F)) {

		int sclIndex = rx_buffer_uart[2] - 0x30; //locate which scale the response is from
		char sclMode = scale_activecmd[sclIndex - 1]; //restore last command issued

		//switch(scale_command[3])
		switch (sclMode) {

		case Read_Decimal:  //ASCII D
			scale_decimal[sclIndex - 1] = rx_buffer_uart[3] - 0x30;
			scale_init_flag[sclIndex - 1] = 1;
			break;

		case Read_Weight:  //ASCII t
			for (int i = 0; i < 6; i++) {
				scale_weight[i] = rx_buffer_uart[i + 3];
			}

			scale_values[sclIndex -1] = atof(scale_weight) / pow(10, scale_decimal[sclIndex - 1]);

			/*scale_data_f = atof(scale_weight) / pow(10, scale_decimal[sclIndex - 1]);
			memcpy(scale_data, &scale_data_f, sizeof(scale_data));
			scale_values[sclIndex -1] = scale_data_f;
			holding_register_value[Scale1_addr_1 + ((sclIndex - 1) << 1)] =	scale_data[1];
			holding_register_value[Scale1_addr_2 + ((sclIndex - 1) << 1)] =	scale_data[0];
			*/

			break;

		case Calibration:  //ASCII s
			break;

		case Zero_Setting:  //ASCII z
			break;

		default:
			break;
		}

		serialDeviceMode = SerialDeviceMode_None;
		serialIndex++;
		serialTimeout = 0;

	} else {
		//UART2_TransmitMessage("Error\r");
	}
}
