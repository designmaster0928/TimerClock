#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))

#include "process.h"
#include "main.h"

float scale_TareMemory[5] = { 0 };
float dosingSpeed[5] = { 0 };
float lastDosingSpeedScale[5] = { 0 };
long timers[20] = { 0 };

//coil, open, closed
int valves[6][3] = { { 1, 1, 2 }, { 2, 3, 4 }, { 3, 5, 6 }, { 4, 7, 8 }, { 5, 9,
		10 }, { 6, 11, 12 } };

/*******************************************************************************
 * Function name: ReservationManager
 * Description: Process reservation requests with reqest, deligate and index
 *              according to pCON Standarts
 * Input: reg: 16-bit register address for the first device register
 * output: none
 * Return value: none
 *******************************************************************************/
void ReservationManager(int regOffset) {

	int regOffsetIndex = regOffset + (2 * ReservationSlots);

	for (int i = 0; i <= ReservationSlots - 1; i++) {

		//if the device is not committed and a request slot is active, register it
		if (holding_register_value[regOffset + i] == 1
				&& holding_register_value[regOffsetIndex] == 0) {
			holding_register_value[regOffset + i] = 2;
			holding_register_value[regOffset + ReservationSlots + i] = 1;
			holding_register_value[regOffsetIndex] = i + 1;
		}

		//clear device request when it has been unregistered
		if (holding_register_value[regOffset + i] == 0
				&& holding_register_value[regOffsetIndex] == i + 1) {
			holding_register_value[regOffset + i] = 0;
			holding_register_value[regOffset + ReservationSlots + i] = 0;
			holding_register_value[regOffsetIndex] = 0;
		}
	}
}

/*******************************************************************************
 * Function name: ProcessTank
 * Description: Process a dosing process from a tank to the outlet according to
 * 		       pCON Standart Infrastructure registers and Seps
 * Input: reg: 16-bit registers for the tank + address for the first device reg.
 * output: none
 * Return value: none
 *******************************************************************************/
void ProcessTank(int Tank, int regOffset) {

	int timerOffset = (Tank - 1) * 10;

	//forward device lock as MISC Busy
	holding_register_value[regOffset + STA_MISC_addr] = GetInput(16);
	//forward tripped fuse as error
	if (GetInput(13) == 0 || GetInput(14) == 0)
		holding_register_value[regOffset + STA_Error_addr] = 1;
	else
		holding_register_value[regOffset + STA_Error_addr] = 0;

	//reset process complete falg
	if (holding_register_value[regOffset + CTR_ProcessEnd_addr] != 0)
		holding_register_value[regOffset + CTR_ProcessEnd_addr] = 0;

	//set the total weight for the device to scale WHEN scales are used
	if (holding_register_value[BI_Scale_Count_addr] != 0)
		RSetFloat(regOffset + STA_TotalWeight_addr, scale_values[Tank - 1]);

	//calculate current weight and forward to Deviceblock
	float currentWeight = scale_TareMemory[Tank - 1] - scale_values[Tank - 1];

	//channel is in counter mode
	if (CHECK_BIT(holding_register_value[Parameter2], Tank) != 0) {
		uint32_t CalValue_l = holding_register_value[Counter_x_CalValue_addr]
				<< 16 | holding_register_value[Counter_x_CalValue_addr_2];
		float CalValue = *(float*) (&CalValue_l);
		currentWeight = counter_values[Tank - 1] * CalValue;
	}
	RSetFloat(regOffset + STA_Weight_addr, currentWeight);

	//cacluate dosing speed for tank ever 10 seconds
	if ((HAL_GetTick() - timers[timerOffset + 1]) > 3 * 1000) {
		dosingSpeed[Tank - 1] = (currentWeight - lastDosingSpeedScale[Tank - 1])
				* 20;
		if (dosingSpeed[Tank - 1] < 0)
			dosingSpeed[Tank - 1] = 0;
		lastDosingSpeedScale[Tank - 1] = currentWeight;
		timers[timerOffset + 1] = HAL_GetTick();
	}
	//forward transportspeed to device interface
	RSetFloat(regOffset + STA_JobSpeed_addr, dosingSpeed[Tank - 1]);

	//stop command issued
	if (holding_register_value[regOffset + CTR_StopCharge_addr] == 1) {
		//if device is busy, raise to stopping sequence
		if (holding_register_value[regOffset + STA_Step_Charge_addr] > 0)
			holding_register_value[regOffset + STA_Step_Charge_addr] = 110;

		holding_register_value[regOffset + CTR_StopCharge_addr] = 0;
	}

	uint8_t dest = holding_register_value[regOffset + PRD_Destination_addr];

	//switch thru step numbers
	switch (holding_register_value[regOffset + STA_Step_Charge_addr]) {

	//Idle - take job if available
	case 0:
		//start flag
		if (holding_register_value[regOffset + CTR_StartCharge_addr] == 1) {
			holding_register_value[regOffset + CTR_StartCharge_addr] = 0;

			holding_register_value[regOffset + STA_Charging_addr] = 1;
			holding_register_value[regOffset + STA_MatError_addr] = 0;

			holding_register_value[regOffset + STA_Step_Charge_addr] = 10;
		}
		break;

		//wait for device enable
	case 10:
		//check for device locked flag
		if (holding_register_value[DeviceLocked_addr] == 0) {
			holding_register_value[regOffset + STA_Step_Charge_addr] = 60;
		}
		break;

		//set scale tare memory
	case 60:
		scale_TareMemory[Tank - 1] = scale_values[Tank - 1];
		counter_values[Tank - 1] = 0;
		if (currentWeight > -0.1 && currentWeight < 0.1) {
			holding_register_value[regOffset + STA_Step_Charge_addr] = 20;
		}
		break;

		//create pipe route
	case 20:
		//tank 1 needs the tankoutlet itself + destination valve
		//matrix:    Tank1		tankout = 5,   lineout = out 1 or 2
		//matrix:    Tank2		tankout = 6,   lineout = out 3 or 4
		if (Tank == 1) {
			SetOutput(5);
			if (dest == 1)
				SetOutput(1);
			if (dest == 2)
				SetOutput(2);
		}
		if (Tank == 2) {
			SetOutput(6);
			if (dest == 1)
				SetOutput(3);
			if (dest == 2)
				SetOutput(4);
		}

		if (Tank == 1 && GetValveState(5) == 2
				&& ((dest == 1 && GetValveState(1) == 2 && GetValveState(2) == 1)
						|| (dest == 2 && GetValveState(1) == 1
								&& GetValveState(2) == 2))) {
			//start timer for minflow detect
			timers[timerOffset + 2] = HAL_GetTick();
			holding_register_value[regOffset + STA_Step_Charge_addr] = 70;
		}

		if (Tank == 2 && GetValveState(6) == 2
				&& ((dest == 1 && GetValveState(3) == 2 && GetValveState(4) == 1)
						|| (dest == 2 && GetValveState(3) == 1
								&& GetValveState(4) == 2))) {
			//start timer for minflow detect
			timers[timerOffset + 2] = HAL_GetTick();
			holding_register_value[regOffset + STA_Step_Charge_addr] = 70;
		}

		break;

		//Dose material until setpoint is reached
	case 70:

		//activate pump
		if (Tank == 1)
			SetOutput(7);
		if (Tank == 2)
			SetOutput(8);

		//pump has run for its minimum flow check time
		if ((HAL_GetTick() - timers[timerOffset + 2])
				> RGetLong(regOffset + CFG_MinFlowTime_addr)
				|| timers[timerOffset + 2] == 999999) {

			//flowrate fell below system setting - raise error (transport cancles)
			if (dosingSpeed[Tank - 1]
					< RGetFloat(regOffset + CFG_MinFlow_addr)) {
				holding_register_value[regOffset + STA_MatError_addr] = 1;
			}
			//override timer value so roll over is a non issue
			timers[timerOffset + 2] = 999999;
		}

		if ((currentWeight >= RGetFloat(regOffset + PRD_PreStop_addr))
				|| holding_register_value[regOffset + STA_MatError_addr] == 1) {
			if (Tank == 1)
				ClearOutput(7);
			if (Tank == 2)
				ClearOutput(8);
			holding_register_value[regOffset + STA_Step_Charge_addr] = 110;
		}
		break;

		//reset transport route
	case 110:

		//clearing all outputs dedicated to this device and check valve status
		if (Tank == 1) {
			ClearOutput(5);
			ClearOutput(1);
			ClearOutput(2);
			ClearOutput(7);

			//all inputs alligned correctly >> move forward
			if (GetValveState(5) == 1 && GetValveState(1) == 1
					&& GetValveState(2) == 1) {
				holding_register_value[regOffset + STA_Step_Charge_addr] = 130;
				timers[timerOffset + 0] = HAL_GetTick();
			}
		}
		if (Tank == 2) {
			ClearOutput(6);
			ClearOutput(3);
			ClearOutput(4);
			ClearOutput(8);
			if (GetValveState(6) == 1 && GetValveState(3) == 1
					&& GetValveState(4) == 1) {
				holding_register_value[regOffset + STA_Step_Charge_addr] = 130;
				timers[timerOffset + 0] = HAL_GetTick();
			}
		}

		break;

		//stabilize scale - wait for preset period - then close
	case 130:
		if ((HAL_GetTick() - timers[timerOffset + 0])
				>= RGetLong(regOffset + CFG_Chg_Stab_addr)) {
			holding_register_value[regOffset + STA_Step_Charge_addr] = 0;
			holding_register_value[regOffset + STA_Charging_addr] = 0;
		}
		break;
	}
}

int GetValveState(int val) {
	int fClose = 0;
	int fOpen = 0;

	//check if input is simulated >> cacluate state, otherwise read input
	if (CHECK_BIT(holding_register_value[Parameter1], valves[val - 1][2] - 1)
			!= 0)
		fClose = GetOutput(valves[val - 1][0]) == 0;
	else
		fClose = GetInput(valves[val - 1][2]);

	//check if input is simulated >> cacluate state, otherwise read input
	if (CHECK_BIT(holding_register_value[Parameter1], valves[val - 1][1] - 1)
			!= 0)
		fOpen = GetOutput(valves[val - 1][0]) == 1;
	else
		fOpen = GetInput(valves[val - 1][1]);

	if (fClose == 1 && fOpen == 0)
		return 1;
	else if (fClose == 0 && fOpen == 1)
		return 2;
	else
		return 0;
}
