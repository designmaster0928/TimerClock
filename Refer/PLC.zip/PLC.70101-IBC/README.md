# PLC.70101-IBC
Softtec Master Series - IBC Station Controller

Special board for IBC / WHF Stations featuring
- Modbus TCP
- RS485 Interface for Laumas TLB
- 8 Outputs
- 16 Inputs
- 1 on Board DS1820B-Z Temperature Probe
