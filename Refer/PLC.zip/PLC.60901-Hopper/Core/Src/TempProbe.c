/*
 * TempProbe.c
 *
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 *
 *      Configure the Boards Parameter in the boardtest.h file
 */

#include "TempProbe.h"







//const float         AVG_SLOPE   = 4.3E-03;      // slope (gradient) of temperature line function  [V/°C]
//const float         V25         = 1.43;         // sensor's voltage at 25°C [V]
//const float         ADC_TO_VOLT = 3.3 / 4096;   // conversion coefficient of digital value to voltage [V]
//                                                // when using 3.3V ref. voltage at 12-bit resolution (2^12 = 4096)
//
//ADC_HandleTypeDef   hadc1;                      // ADC handle
//uint16_t            adcValue;                   // digital value of sensor
//float               vSense;                     // sensor's output voltage [V]
//float               temp;                       // sensor's temperature [°C]
//
//void ChipProbe_Handle(void)
//{
//	   HAL_ADC_Start(&hadc1);                                      // start analog to digital conversion
//	        while(HAL_ADC_PollForConversion(&hadc1, 1000000) != HAL_OK);// wait for completing the conversion
//	        adcValue = HAL_ADC_GetValue(&hadc1);                        // read sensor's digital value
//	        vSense = adcValue * ADC_TO_VOLT;                            // convert sensor's digital value to voltage [V]
//	        /*
//	         * STM32F103xx Reference Manual:
//	         * 11.10 Temperature sensor
//	         * Reading the temperature, Page 235
//	         * Temperature (in °C) = {(V25 - Vsense) / Avg_Slope} + 25
//	         */
//	        temp = (V25 - vSense) / AVG_SLOPE + 25.0f;                  // convert sensor's output voltage to temperature [°C]
//
//}
