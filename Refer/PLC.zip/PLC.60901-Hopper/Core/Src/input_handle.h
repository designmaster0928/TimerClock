/*
 * input_handle.h
 *
 *  Created on: Sep 10, 2022
 *      Author: Developer
 */

#ifndef SRC_INPUT_H_
#define SRC_INPUT_H_


unsigned char SPI2_Read_Byte(void);
unsigned char Byte_4Bit(unsigned char dat);
unsigned char Byte_6Bit(unsigned char dat);
unsigned short ReadInput(void);
unsigned short ReadInput2(void);
void Inputs_Handle(void);

#endif /* SRC_INPUT_H_ */
