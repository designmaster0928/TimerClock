/*
 * boardtests.c
 *
 *  Created on: 9 Sep 2022
 *      Author: Andreas Kisch
 *
 *      Configure the Boards Parameter in the boardtest.h file
 */
#include "main.h"
#include "spi.h"

void SPI2_Send_Byte(unsigned char dat) {
	HAL_SPI_Transmit(&hspi2, &dat, 1, 0xff);
}

void Outputs_Handle(void) {
	HAL_GPIO_WritePin(SPI2_CS_OUT_GPIO_Port, SPI2_CS_OUT_Pin, GPIO_PIN_RESET); //MAX4896 CS pin to

	//out 32 - 17
	SPI2_Send_Byte(holding_register_value[OutputWord2_addr] >> 8);
	SPI2_Send_Byte(holding_register_value[OutputWord2_addr] & 0xFF);
	//out 1 - 16
	SPI2_Send_Byte(holding_register_value[OutputWord1_addr] >> 8);
	SPI2_Send_Byte(holding_register_value[OutputWord1_addr] & 0xFF);

	HAL_GPIO_WritePin(SPI2_CS_OUT_GPIO_Port, SPI2_CS_OUT_Pin, GPIO_PIN_SET); //MAX4896 CS pin to High
}
