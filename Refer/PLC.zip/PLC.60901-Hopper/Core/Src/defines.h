/*
 * defines.h
 *
 *  Created on: 18 Oct 2022
 *      Author: Developer
 */

#ifndef DEFINES_FILE
#define DEFINES_FILE

#define STM32F1xx /*!< Use STM32F0xx libraries */
//#define STM32F4xx /*!< Use STM32F4xx libraries */
//#define STM32F7xx /*!< Use STM32F7xx libraries */

#endif
